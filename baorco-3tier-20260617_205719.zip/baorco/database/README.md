# Database layer

This project uses **Microsoft SQL Server 2022** as its single source of
truth. It runs as its own Docker service (`mssql`) with a persistent
named volume, so data survives `docker compose down` (only `down -v`
wipes it).

## Why there's no `init.sql` here

Unlike the Postgres/MySQL Docker images, the official
`mcr.microsoft.com/mssql/server` image does **not** auto-run `.sql`
scripts on first boot. Two things handle database setup instead:

1. **The `mssql` service itself** (see root `docker-compose.yml`) just
   boots a bare SQL Server instance with only the `master` database.
2. **The backend's `ensure_database` management command**
   (`backend/accounts/management/commands/ensure_database.py`) connects
   to `master` directly via `pyodbc` and creates the
   `BAORCO_Shop` database if it doesn't exist yet — this runs
   automatically as the first step of the backend container's startup,
   before `migrate`. This is a deliberate fix: Django's `migrate` only
   ever creates **tables**, never the database itself, which is an easy
   trap on MSSQL/Postgres/MySQL (unlike SQLite).

So the actual "init" logic lives with the backend, not as a SQL script
mounted into this folder. If you'd rather have a true init script
mounted into the container, you can add one here and wire it into a
one-shot `db-init` Compose service using `sqlcmd`, but the current
approach has the advantage of working identically on Railway, Azure, or
any other platform without compose-specific init tricks.

## Connection details (matches `.env`)

| Setting | Value |
|---|---|
| Host (inside Docker network) | `mssql` |
| Port | `1433` |
| Database | `BAORCO_Shop` |
| User | `sa` |
| Password | set via `DB_PASSWORD` in `.env` |
| Driver | ODBC Driver 18 for SQL Server |

## Resource requirements

SQL Server on Linux needs **at least 2GB of RAM** just to boot. If the
`mssql` container keeps restarting, check your server's memory plan
before debugging anything else — this is the #1 cause of "it works
locally but crash-loops on my VPS."

## Backup

```bash
docker compose exec mssql /opt/mssql-tools18/bin/sqlcmd \
  -S localhost -U sa -P "$DB_PASSWORD" -C \
  -Q "BACKUP DATABASE BAORCO_Shop TO DISK = '/var/opt/mssql/backup/BAORCO_Shop.bak'"

docker compose cp mssql:/var/opt/mssql/backup/BAORCO_Shop.bak ./database/backups/
```

## Restore

```bash
docker compose cp ./database/backups/BAORCO_Shop.bak mssql:/var/opt/mssql/backup/BAORCO_Shop.bak

docker compose exec mssql /opt/mssql-tools18/bin/sqlcmd \
  -S localhost -U sa -P "$DB_PASSWORD" -C \
  -Q "RESTORE DATABASE BAORCO_Shop FROM DISK = '/var/opt/mssql/backup/BAORCO_Shop.bak' WITH REPLACE"
```
