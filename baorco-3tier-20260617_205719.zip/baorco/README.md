# باورکو (BAORCO) — Online Furniture Shop

A proper 3-tier e-commerce platform: a React storefront, a Django REST
API, and an MSSQL database, each independently deployable and each
living in its own folder.

```
baorco/
├── frontend/    React (Vite) storefront — what customers see
├── backend/     Django REST Framework API — all business logic
├── database/    MSSQL docs, backups, connection info
├── docker-compose.yml
└── .env.example
```

## Architecture

```
                         ┌─────────────────────┐
   Browser / Phone ───▶  │  frontend (nginx)    │  :80
                         │  - serves React SPA  │
                         │  - proxies /api,     │
                         │    /admin, /static,  │
                         │    /media to backend │
                         └──────────┬───────────┘
                                    │
                         ┌──────────▼───────────┐
                         │  backend (Django)    │  :8000 (internal)
                         │  REST API + admin    │
                         └──────────┬───────────┘
                          ┌─────────┼─────────┐
                          ▼         ▼         ▼
                     ┌────────┐ ┌──────┐ ┌─────────┐
                     │ mssql  │ │redis │ │ celery  │
                     │  (DB)  │ │cache │ │ worker/ │
                     │        │ │      │ │ beat    │
                     └────────┘ └──────┘ └─────────┘
```

The frontend's nginx is the **only** public entrypoint. There is no
separate "gateway" container — the frontend image's nginx does double
duty as both the SPA host and the reverse proxy, which keeps the
service count down without merging the codebases.

Staff/admin work continues to happen at `/admin/` (Django admin) — the
React app is the **customer-facing storefront only**. Building a
matching React admin panel is a reasonable next step, but Django admin
already covers products/orders/accounting management today, so it
wasn't duplicated here.

## Quick start

```bash
cd baorco
cp .env.example .env
nano .env                      # set SECRET_KEY and DB_PASSWORD at minimum

docker compose build
docker compose up -d

# wait ~60s for mssql to finish booting, then:
docker compose exec backend python manage.py createsuperuser
```

Visit:
- **Storefront**: `http://your-server/`
- **API docs**: `http://your-server/api/docs/`
- **Django admin**: `http://your-server/admin/`

## Local frontend development (hot reload)

```bash
cd frontend
npm install
npm run dev          # http://localhost:5173, proxies /api to localhost:8000
```

Run the backend separately for this (`cd backend && python manage.py runserver`,
using `backend/.env.example` → `backend/.env` with `USE_MSSQL=false` for
zero-setup SQLite).

## Which `.env` do I edit?

| File | Used by | When |
|---|---|---|
| `.env` (root) | `docker compose up` — the whole stack | Deploying for real |
| `backend/.env` | `python manage.py runserver` alone | Quick local API work, no Docker |

Editing `backend/.env` has **no effect** on `docker compose up` — Compose
only reads the root `.env`. This is a common trap, documented here on
purpose.

## Folder details

- **`frontend/README` (this section)** — Vite + React 18, Tailwind,
  React Router, Persian/RTL throughout, JWT auth with automatic token
  refresh, cart synced to the backend (not just local state).
- **`backend/`** — Django REST Framework, JWT auth, SMS.ir OTP
  verification, Celery background tasks, drf-spectacular API docs.
- **`database/README.md`** — MSSQL connection details, backup/restore
  commands, and why there's no `init.sql` (see that file — it's a real
  gotcha with the official MSSQL Docker image).

## Known scope cuts (intentional)

- Admin React panel: not built. Django admin already covers this.
- Payment gateway integration: `payment_method` is captured at checkout
  but no live gateway (Zarinpal etc.) is wired up — add that to
  `backend/orders/views.py` `OrderViewSet.create` when ready.
- Product image upload UI: managed via Django admin for now.
