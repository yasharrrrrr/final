from rest_framework import viewsets, status, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter
from products.models import Category, Product, ProductImage, ProductReview, Wishlist, Discount
from products.serializers import (
    CategorySerializer, ProductListSerializer, ProductDetailSerializer,
    ProductCreateUpdateSerializer, ProductImageSerializer, ProductReviewSerializer,
    WishlistSerializer, DiscountSerializer
)
import logging

logger = logging.getLogger('baorco')

class CategoryViewSet(viewsets.ModelViewSet):
    """
    ViewSet for product categories
    """
    queryset = Category.objects.filter(is_active=True)
    serializer_class = CategorySerializer
    lookup_field = 'slug'
    
    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            permission_classes = [permissions.AllowAny]
        else:
            permission_classes = [permissions.IsAuthenticated]
        return [permission() for permission in permission_classes]
    
    def check_admin_permission(self, request):
        if not request.user.is_admin or not request.user.admin_profile.can_manage_products:
            raise permissions.PermissionDenied('شما اجازه دسترسی ندارید')


class ProductViewSet(viewsets.ModelViewSet):
    """
    ViewSet for products with full CRUD for admins and read-only for customers
    """
    queryset = Product.objects.filter(status='active')
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['category', 'brand', 'color', 'is_featured', 'is_bestseller', 'allows_installment']
    search_fields = ['name', 'description', 'sku', 'brand']
    ordering_fields = ['created_at', 'base_price', 'sales_count', 'rating']
    ordering = ['-created_at']
    
    def get_serializer_class(self):
        if self.action == 'retrieve':
            return ProductDetailSerializer
        elif self.action in ['create', 'update', 'partial_update']:
            return ProductCreateUpdateSerializer
        return ProductListSerializer
    
    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            permission_classes = [permissions.AllowAny]
        else:
            permission_classes = [permissions.IsAuthenticated]
        return [permission() for permission in permission_classes]
    
    def get_queryset(self):
        if self.request.user.is_authenticated and self.request.user.is_admin:
            return Product.objects.all()
        return Product.objects.filter(status='active')
    
    def check_admin_permission(self, request):
        if not request.user.is_admin or not request.user.admin_profile.can_manage_products:
            raise permissions.PermissionDenied('شما اجازه دسترسی ندارید')
    
    def create(self, request, *args, **kwargs):
        self.check_admin_permission(request)
        return super().create(request, *args, **kwargs)
    
    def update(self, request, *args, **kwargs):
        self.check_admin_permission(request)
        return super().update(request, *args, **kwargs)
    
    def destroy(self, request, *args, **kwargs):
        self.check_admin_permission(request)
        return super().destroy(request, *args, **kwargs)
    
    def retrieve(self, request, *args, **kwargs):
        response = super().retrieve(request, *args, **kwargs)
        # Increment view count
        product = self.get_object()
        product.views_count += 1
        product.save(update_fields=['views_count'])
        return response
    
    @action(detail=True, methods=['post'])
    def add_image(self, request, pk=None):
        """Add additional image to product"""
        self.check_admin_permission(request)
        
        product = self.get_object()
        serializer = ProductImageSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(product=product)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=True, methods=['get'])
    def images(self, request, pk=None):
        """Get all images for product"""
        product = self.get_object()
        images = product.images.all()
        serializer = ProductImageSerializer(images, many=True)
        return Response(serializer.data)
    
    @action(detail=True, methods=['get', 'post'])
    def reviews(self, request, pk=None):
        """Get reviews or add new review for product"""
        product = self.get_object()
        
        if request.method == 'GET':
            reviews = product.reviews.all()
            serializer = ProductReviewSerializer(reviews, many=True)
            return Response(serializer.data)
        
        elif request.method == 'POST':
            if not request.user.is_authenticated:
                return Response(
                    {'error': 'برای نوشتن نظر باید وارد شوید'},
                    status=status.HTTP_401_UNAUTHORIZED
                )
            
            # Check if user already reviewed this product
            if product.reviews.filter(customer=request.user).exists():
                return Response(
                    {'error': 'شما قبلاً برای این محصول نظر داده‌اید'},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            serializer = ProductReviewSerializer(data=request.data)
            if serializer.is_valid():
                review = serializer.save(product=product, customer=request.user)
                
                # Update product rating
                reviews = product.reviews.all()
                avg_rating = sum(r.rating for r in reviews) / reviews.count()
                product.rating = avg_rating
                product.save(update_fields=['rating'])
                
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=True, methods=['post'])
    def add_to_wishlist(self, request, pk=None):
        """Add product to wishlist"""
        if not request.user.is_authenticated:
            return Response(
                {'error': 'برای اضافه کردن به لیست آرزو باید وارد شوید'},
                status=status.HTTP_401_UNAUTHORIZED
            )
        
        product = self.get_object()
        wishlist_item, created = Wishlist.objects.get_or_create(
            customer=request.user,
            product=product
        )
        
        if created:
            return Response(
                {'message': 'محصول به لیست آرزو اضافه شد'},
                status=status.HTTP_201_CREATED
            )
        else:
            return Response(
                {'message': 'این محصول قبلاً در لیست آرزو وجود دارد'},
                status=status.HTTP_400_BAD_REQUEST
            )
    
    @action(detail=True, methods=['delete'])
    def remove_from_wishlist(self, request, pk=None):
        """Remove product from wishlist"""
        if not request.user.is_authenticated:
            return Response(
                {'error': 'درخواست نامعتبر'},
                status=status.HTTP_401_UNAUTHORIZED
            )
        
        product = self.get_object()
        try:
            wishlist_item = Wishlist.objects.get(customer=request.user, product=product)
            wishlist_item.delete()
            return Response({'message': 'محصول از لیست آرزو حذف شد'})
        except Wishlist.DoesNotExist:
            return Response(
                {'error': 'این محصول در لیست آرزو وجود ندارد'},
                status=status.HTTP_404_NOT_FOUND
            )
    
    @action(detail=False, methods=['get'])
    def featured(self, request):
        """Get featured products"""
        products = self.get_queryset().filter(is_featured=True)[:10]
        serializer = self.get_serializer(products, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def bestsellers(self, request):
        """Get bestselling products"""
        products = self.get_queryset().filter(is_bestseller=True).order_by('-sales_count')[:10]
        serializer = self.get_serializer(products, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def on_sale(self, request):
        """Get products on sale"""
        products = self.get_queryset().filter(discounted_price__isnull=False)
        serializer = self.get_serializer(products, many=True)
        return Response(serializer.data)


class WishlistViewSet(viewsets.ModelViewSet):
    """
    ViewSet for user wishlist
    """
    serializer_class = WishlistSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        if self.request.user.is_admin:
            return Wishlist.objects.all()
        return Wishlist.objects.filter(customer=self.request.user)
    
    def perform_create(self, serializer):
        serializer.save(customer=self.request.user)
    
    @action(detail=False, methods=['get'])
    def my_wishlist(self, request):
        """Get current user's wishlist"""
        wishlist = self.get_queryset()
        serializer = self.get_serializer(wishlist, many=True)
        return Response(serializer.data)


class DiscountViewSet(viewsets.ModelViewSet):
    """
    ViewSet for discount codes management
    """
    queryset = Discount.objects.filter(is_active=True)
    serializer_class = DiscountSerializer
    
    def get_permissions(self):
        if self.action == 'retrieve':
            permission_classes = [permissions.AllowAny]
        else:
            permission_classes = [permissions.IsAuthenticated]
        return [permission() for permission in permission_classes]
    
    def check_admin_permission(self, request):
        if not request.user.is_admin or not request.user.admin_profile.can_manage_products:
            raise permissions.PermissionDenied('شما اجازه دسترسی ندارید')
    
    def get_queryset(self):
        if self.request.user.is_authenticated and self.request.user.is_admin:
            return Discount.objects.all()
        return Discount.objects.filter(is_active=True)
    
    def create(self, request, *args, **kwargs):
        self.check_admin_permission(request)
        return super().create(request, *args, **kwargs)
    
    def update(self, request, *args, **kwargs):
        self.check_admin_permission(request)
        return super().update(request, *args, **kwargs)
    
    def destroy(self, request, *args, **kwargs):
        self.check_admin_permission(request)
        return super().destroy(request, *args, **kwargs)
    
    @action(detail=False, methods=['post'])
    def validate_code(self, request):
        """Validate and get discount code details"""
        code = request.data.get('code')
        if not code:
            return Response(
                {'error': 'کد تخفیف الزامی است'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            discount = Discount.objects.get(code=code, is_active=True)
            
            from django.utils import timezone
            if discount.start_date > timezone.now() or discount.end_date < timezone.now():
                return Response(
                    {'error': 'این کد تخفیف معتبر نیست'},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            if discount.max_usage and discount.current_usage >= discount.max_usage:
                return Response(
                    {'error': 'این کد تخفیف منقضی شده است'},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            serializer = DiscountSerializer(discount)
            return Response(serializer.data)
        except Discount.DoesNotExist:
            return Response(
                {'error': 'کد تخفیف نامعتبر است'},
                status=status.HTTP_404_NOT_FOUND
            )
