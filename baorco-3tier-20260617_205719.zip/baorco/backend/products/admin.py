from django.contrib import admin
from products.models import Category, Product, ProductImage, ProductReview, Wishlist, Discount

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'slug', 'is_active', 'created_at')
    list_filter = ('is_active', 'created_at')
    search_fields = ('name', 'slug')
    prepopulated_fields = {'slug': ('name',)}
    readonly_fields = ('created_at', 'updated_at')

class ProductImageInline(admin.TabularInline):
    model = ProductImage
    extra = 1

class ProductReviewInline(admin.TabularInline):
    model = ProductReview
    extra = 0
    readonly_fields = ('customer', 'rating', 'review', 'created_at')
    can_delete = False

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'sku', 'category', 'current_price', 'quantity', 'rating', 'status', 'created_at')
    list_filter = ('category', 'status', 'is_featured', 'is_bestseller', 'allows_installment', 'created_at')
    search_fields = ('name', 'sku', 'description')
    readonly_fields = ('created_at', 'updated_at', 'views_count', 'sales_count')
    prepopulated_fields = {'slug': ('name',)}
    inlines = [ProductImageInline]
    
    fieldsets = (
        ('Basic Info', {
            'fields': ('name', 'slug', 'category', 'description', 'detailed_description')
        }),
        ('Pricing', {
            'fields': ('base_price', 'discounted_price', 'cost_price')
        }),
        ('Stock & SKU', {
            'fields': ('quantity', 'sku')
        }),
        ('Product Details', {
            'fields': ('dimensions', 'weight', 'material', 'color', 'brand', 'warranty_months')
        }),
        ('Media', {
            'fields': ('image',)
        }),
        ('Status & Visibility', {
            'fields': ('status', 'is_featured', 'is_bestseller')
        }),
        ('Installment', {
            'fields': ('allows_installment', 'max_installment_months')
        }),
        ('Statistics', {
            'fields': ('views_count', 'sales_count', 'rating'),
            'classes': ('collapse',)
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

@admin.register(ProductImage)
class ProductImageAdmin(admin.ModelAdmin):
    list_display = ('product', 'is_primary', 'created_at')
    list_filter = ('is_primary', 'created_at')
    search_fields = ('product__name', 'alt_text')

@admin.register(ProductReview)
class ProductReviewAdmin(admin.ModelAdmin):
    list_display = ('product', 'customer', 'rating', 'is_verified_purchase', 'created_at')
    list_filter = ('rating', 'is_verified_purchase', 'created_at')
    search_fields = ('product__name', 'customer__username', 'title')
    readonly_fields = ('product', 'customer', 'created_at', 'updated_at')

@admin.register(Wishlist)
class WishlistAdmin(admin.ModelAdmin):
    list_display = ('customer', 'product', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('customer__username', 'product__name')

@admin.register(Discount)
class DiscountAdmin(admin.ModelAdmin):
    list_display = ('code', 'discount_type', 'discount_value', 'current_usage', 'max_usage', 'is_active')
    list_filter = ('discount_type', 'is_active', 'start_date', 'end_date')
    search_fields = ('code', 'description')
    readonly_fields = ('current_usage', 'created_at')
    filter_horizontal = ('applicable_products', 'applicable_categories')
