from rest_framework import serializers
from products.models import Category, Product, ProductImage, ProductReview, Wishlist, Discount

class CategorySerializer(serializers.ModelSerializer):
    products_count = serializers.SerializerMethodField()
    
    class Meta:
        model = Category
        fields = ['id', 'name', 'slug', 'description', 'image', 'is_active', 'products_count']
        read_only_fields = ['id', 'slug']
    
    def get_products_count(self, obj):
        return obj.products.filter(status='active').count()


class ProductImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductImage
        fields = ['id', 'image', 'alt_text', 'is_primary']


class ProductReviewSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(source='customer.get_full_name', read_only=True)
    
    class Meta:
        model = ProductReview
        fields = ['id', 'customer_name', 'rating', 'title', 'review', 
                  'is_verified_purchase', 'helpful_count', 'created_at']
        read_only_fields = ['id', 'customer_name', 'is_verified_purchase', 'helpful_count', 'created_at']


class ProductListSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.name', read_only=True)
    image_url = serializers.SerializerMethodField()
    
    class Meta:
        model = Product
        fields = ['id', 'name', 'slug', 'category_name', 'image_url', 'current_price', 
                  'base_price', 'discount_percentage', 'quantity', 'rating', 
                  'is_featured', 'is_bestseller', 'created_at']
        read_only_fields = ['id', 'slug', 'created_at']
    
    def get_image_url(self, obj):
        request = self.context.get('request')
        if obj.image and hasattr(obj.image, 'url'):
            return request.build_absolute_uri(obj.image.url) if request else obj.image.url
        return None


class ProductDetailSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.name', read_only=True)
    images = ProductImageSerializer(many=True, read_only=True)
    reviews = ProductReviewSerializer(many=True, read_only=True)
    average_rating = serializers.SerializerMethodField()
    review_count = serializers.SerializerMethodField()
    image_url = serializers.SerializerMethodField()
    
    class Meta:
        model = Product
        fields = ['id', 'name', 'slug', 'category_name', 'description', 
                  'detailed_description', 'image_url', 'images', 'base_price', 
                  'discounted_price', 'current_price', 'discount_percentage', 
                  'quantity', 'sku', 'dimensions', 'weight', 'material', 'color', 
                  'brand', 'warranty_months', 'status', 'is_featured', 'is_bestseller', 
                  'allows_installment', 'max_installment_months', 'views_count', 
                  'sales_count', 'rating', 'average_rating', 'review_count', 
                  'reviews', 'created_at', 'updated_at']
        read_only_fields = ['id', 'slug', 'views_count', 'sales_count', 'created_at', 'updated_at']
    
    def get_average_rating(self, obj):
        reviews = obj.reviews.all()
        if reviews:
            return sum(r.rating for r in reviews) / reviews.count()
        return 0
    
    def get_review_count(self, obj):
        return obj.reviews.count()
    
    def get_image_url(self, obj):
        request = self.context.get('request')
        if obj.image and hasattr(obj.image, 'url'):
            return request.build_absolute_uri(obj.image.url) if request else obj.image.url
        return None


class ProductCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ['name', 'category', 'description', 'detailed_description', 
                  'base_price', 'discounted_price', 'cost_price', 'quantity', 'sku', 
                  'dimensions', 'weight', 'material', 'color', 'brand', 
                  'warranty_months', 'image', 'status', 'is_featured', 'is_bestseller', 
                  'allows_installment', 'max_installment_months']
    
    def create(self, validated_data):
        return Product.objects.create(**validated_data)
    
    def update(self, instance, validated_data):
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()
        return instance


class WishlistSerializer(serializers.ModelSerializer):
    product = ProductListSerializer(read_only=True)
    product_id = serializers.IntegerField(write_only=True)
    
    class Meta:
        model = Wishlist
        fields = ['id', 'product', 'product_id', 'created_at']
        read_only_fields = ['id', 'created_at']


class DiscountSerializer(serializers.ModelSerializer):
    applicable_product_ids = serializers.PrimaryKeyRelatedField(
        many=True, 
        write_only=True, 
        queryset=Product.objects.all(),
        source='applicable_products'
    )
    applicable_category_ids = serializers.PrimaryKeyRelatedField(
        many=True, 
        write_only=True, 
        queryset=Category.objects.all(),
        source='applicable_categories'
    )
    
    class Meta:
        model = Discount
        fields = ['id', 'code', 'description', 'discount_type', 'discount_value', 
                  'applicable_product_ids', 'applicable_category_ids', 
                  'min_purchase_amount', 'max_usage', 'current_usage', 
                  'start_date', 'end_date', 'is_active', 'created_at']
        read_only_fields = ['id', 'current_usage', 'created_at']
