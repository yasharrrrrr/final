# __init__.py for products
default_app_config = 'products.apps.ProductsConfig'
