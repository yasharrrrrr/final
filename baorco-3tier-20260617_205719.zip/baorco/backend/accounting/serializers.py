from rest_framework import serializers
from accounting.models import (
    Account, JournalEntry, JournalLine, Invoice, Expense, 
    FinancialReport, BankAccount, DailyBalance
)

class AccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = Account
        fields = ['id', 'account_number', 'name', 'account_type', 'balance', 'is_active']

class JournalLineSerializer(serializers.ModelSerializer):
    account_name = serializers.CharField(source='account.name', read_only=True)
    
    class Meta:
        model = JournalLine
        fields = ['id', 'account', 'account_name', 'transaction_type', 'amount', 'description']

class JournalEntrySerializer(serializers.ModelSerializer):
    lines = JournalLineSerializer(many=True, read_only=True)
    created_by_name = serializers.CharField(source='created_by.username', read_only=True)
    
    class Meta:
        model = JournalEntry
        fields = ['id', 'entry_number', 'entry_date', 'description', 'created_by_name',
                  'reference_type', 'reference_id', 'is_posted', 'lines', 'created_at']
        read_only_fields = ['entry_number', 'created_at']

class InvoiceSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(source='customer.get_full_name', read_only=True)
    order_number = serializers.CharField(source='order.order_number', read_only=True)
    
    class Meta:
        model = Invoice
        fields = ['id', 'invoice_number', 'order_number', 'customer_name', 'issue_date',
                  'due_date', 'status', 'subtotal', 'tax_rate', 'tax_amount', 
                  'discount_amount', 'total', 'paid_amount', 'remaining_amount']
        read_only_fields = ['invoice_number', 'tax_amount', 'total', 'remaining_amount']

class ExpenseSerializer(serializers.ModelSerializer):
    submitted_by_name = serializers.CharField(source='submitted_by.username', read_only=True)
    approved_by_name = serializers.CharField(source='approved_by.username', read_only=True)
    
    class Meta:
        model = Expense
        fields = ['id', 'expense_number', 'category', 'description', 'amount', 
                  'payment_method', 'expense_date', 'account', 'submitted_by_name',
                  'approved_by_name', 'is_approved', 'receipt', 'created_at']
        read_only_fields = ['expense_number', 'created_at']

class FinancialReportSerializer(serializers.ModelSerializer):
    generated_by_name = serializers.CharField(source='generated_by.username', read_only=True)
    
    class Meta:
        model = FinancialReport
        fields = ['id', 'report_type', 'period_start', 'period_end', 'data', 
                  'generated_by_name', 'created_at']
        read_only_fields = ['created_at']

class BankAccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = BankAccount
        fields = ['id', 'account_name', 'bank_name', 'account_number', 'card_number',
                  'iban', 'account_holder', 'balance', 'is_active', 'created_at', 'updated_at']

class DailyBalanceSerializer(serializers.ModelSerializer):
    bank_account_name = serializers.CharField(source='bank_account.account_name', read_only=True)
    
    class Meta:
        model = DailyBalance
        fields = ['id', 'bank_account', 'bank_account_name', 'balance_date', 
                  'opening_balance', 'closing_balance', 'total_debit', 'total_credit']
