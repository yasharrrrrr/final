from django.db import models
from django.utils import timezone

class Account(models.Model):
    """
    Chart of accounts - financial tracking accounts
    """
    ACCOUNT_TYPE_CHOICES = (
        ('asset', 'دارایی'),
        ('liability', 'بدهی'),
        ('equity', 'سرمایه'),
        ('revenue', 'درآمد'),
        ('expense', 'هزینه'),
    )
    
    account_number = models.CharField(max_length=50, unique=True)
    name = models.CharField(max_length=255)
    account_type = models.CharField(max_length=20, choices=ACCOUNT_TYPE_CHOICES)
    description = models.TextField(blank=True, null=True)
    balance = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'حساب'
        verbose_name_plural = 'حسابات'
        ordering = ['account_number']
    
    def __str__(self):
        return f"{self.account_number} - {self.name}"


class JournalEntry(models.Model):
    """
    General journal entries for accounting transactions
    """
    entry_number = models.CharField(max_length=50, unique=True)
    entry_date = models.DateField()
    description = models.TextField()
    created_by = models.ForeignKey('accounts.User', on_delete=models.SET_NULL, null=True)
    reference_type = models.CharField(
        max_length=50,
        choices=[
            ('order', 'سفارش'),
            ('payment', 'پرداخت'),
            ('refund', 'بازگشت'),
            ('other', 'سایر'),
        ]
    )
    reference_id = models.CharField(max_length=100, blank=True, null=True)
    is_posted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'ورود دفتر'
        verbose_name_plural = 'ورودهای دفتر'
        ordering = ['-entry_date', '-entry_number']
    
    def __str__(self):
        return f"Journal Entry {self.entry_number}"
    
    def save(self, *args, **kwargs):
        if not self.entry_number:
            import uuid
            self.entry_number = f"JE-{timezone.now().strftime('%Y%m%d')}-{uuid.uuid4().hex[:6].upper()}"
        super().save(*args, **kwargs)


class JournalLine(models.Model):
    """
    Line items in journal entries (debit/credit)
    """
    TRANSACTION_TYPE_CHOICES = (
        ('debit', 'بدهکار'),
        ('credit', 'بستانکار'),
    )
    
    journal_entry = models.ForeignKey(JournalEntry, on_delete=models.CASCADE, related_name='lines')
    account = models.ForeignKey(Account, on_delete=models.PROTECT)
    transaction_type = models.CharField(max_length=20, choices=TRANSACTION_TYPE_CHOICES)
    amount = models.DecimalField(max_digits=18, decimal_places=2)
    description = models.TextField(blank=True, null=True)
    
    class Meta:
        verbose_name = 'خط دفتر'
        verbose_name_plural = 'خطوط دفتر'
    
    def __str__(self):
        return f"{self.journal_entry.entry_number} - {self.account.name}"


class Invoice(models.Model):
    """
    Sales invoices for customers
    """
    INVOICE_STATUS_CHOICES = (
        ('draft', 'پیش‌نویس'),
        ('issued', 'صادر شده'),
        ('sent', 'ارسال شده'),
        ('paid', 'پرداخت شده'),
        ('partially_paid', 'پرداخت جزئی'),
        ('overdue', 'سررسید'),
        ('cancelled', 'لغو شده'),
    )
    
    invoice_number = models.CharField(max_length=50, unique=True)
    order = models.OneToOneField('orders.Order', on_delete=models.CASCADE, related_name='invoice')
    customer = models.ForeignKey('accounts.User', on_delete=models.SET_NULL, null=True)
    
    issue_date = models.DateField()
    due_date = models.DateField()
    status = models.CharField(max_length=20, choices=INVOICE_STATUS_CHOICES, default='draft')
    
    # Amounts
    subtotal = models.DecimalField(max_digits=15, decimal_places=2)
    tax_rate = models.DecimalField(max_digits=5, decimal_places=2, default=9)
    tax_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    discount_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=15, decimal_places=2)
    
    paid_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    remaining_amount = models.DecimalField(max_digits=15, decimal_places=2)
    
    notes = models.TextField(blank=True, null=True)
    terms = models.TextField(blank=True, null=True)
    
    created_by = models.ForeignKey('accounts.User', on_delete=models.SET_NULL, null=True, related_name='invoices_created')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'فاکتور'
        verbose_name_plural = 'فاکتورها'
        ordering = ['-issue_date']
    
    def __str__(self):
        return f"Invoice {self.invoice_number}"
    
    def save(self, *args, **kwargs):
        if not self.invoice_number:
            import uuid
            self.invoice_number = f"INV-{timezone.now().strftime('%Y%m%d')}-{uuid.uuid4().hex[:6].upper()}"
        super().save(*args, **kwargs)


class Expense(models.Model):
    """
    Business expenses tracking
    """
    EXPENSE_CATEGORY_CHOICES = (
        ('shipping', 'حمل و نقل'),
        ('utilities', 'مصارف عمومی'),
        ('salary', 'حقوق'),
        ('marketing', 'بازاریابی'),
        ('maintenance', 'نگهداری'),
        ('office', 'اداری'),
        ('other', 'سایر'),
    )
    
    expense_number = models.CharField(max_length=50, unique=True)
    category = models.CharField(max_length=50, choices=EXPENSE_CATEGORY_CHOICES)
    description = models.TextField()
    amount = models.DecimalField(max_digits=15, decimal_places=2)
    payment_method = models.CharField(max_length=50)
    expense_date = models.DateField()
    account = models.ForeignKey(Account, on_delete=models.PROTECT)
    submitted_by = models.ForeignKey('accounts.User', on_delete=models.SET_NULL, null=True)
    approved_by = models.ForeignKey(
        'accounts.User',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='approved_expenses'
    )
    is_approved = models.BooleanField(default=False)
    receipt = models.FileField(upload_to='receipts/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'هزینه'
        verbose_name_plural = 'هزینه‌ها'
        ordering = ['-expense_date']
    
    def __str__(self):
        return f"Expense {self.expense_number}"
    
    def save(self, *args, **kwargs):
        if not self.expense_number:
            import uuid
            self.expense_number = f"EXP-{timezone.now().strftime('%Y%m%d')}-{uuid.uuid4().hex[:6].upper()}"
        super().save(*args, **kwargs)


class FinancialReport(models.Model):
    """
    Generated financial reports
    """
    REPORT_TYPE_CHOICES = (
        ('income_statement', 'صورت درآمد'),
        ('balance_sheet', 'ترازنامه'),
        ('cash_flow', 'جریان نقدینگی'),
        ('trial_balance', 'میزان تطابق'),
    )
    
    report_type = models.CharField(max_length=50, choices=REPORT_TYPE_CHOICES)
    period_start = models.DateField()
    period_end = models.DateField()
    data = models.JSONField()
    generated_by = models.ForeignKey('accounts.User', on_delete=models.SET_NULL, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'گزارش مالی'
        verbose_name_plural = 'گزارش‌های مالی'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.get_report_type_display()} - {self.period_start} to {self.period_end}"


class BankAccount(models.Model):
    """
    Bank accounts for the business
    """
    account_name = models.CharField(max_length=255)
    bank_name = models.CharField(max_length=255)
    account_number = models.CharField(max_length=50, unique=True)
    card_number = models.CharField(max_length=20, blank=True, null=True)
    iban = models.CharField(max_length=50, blank=True, null=True)
    account_holder = models.CharField(max_length=255)
    balance = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'حساب بانکی'
        verbose_name_plural = 'حسابات بانکی'
    
    def __str__(self):
        return f"{self.account_name} - {self.bank_name}"


class DailyBalance(models.Model):
    """
    Daily balance snapshot for reporting
    """
    bank_account = models.ForeignKey(BankAccount, on_delete=models.CASCADE, related_name='daily_balances')
    balance_date = models.DateField()
    opening_balance = models.DecimalField(max_digits=18, decimal_places=2)
    closing_balance = models.DecimalField(max_digits=18, decimal_places=2)
    total_debit = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    total_credit = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'موجودی روزانه'
        verbose_name_plural = 'موجودی‌های روزانه'
        unique_together = ('bank_account', 'balance_date')
        ordering = ['-balance_date']
    
    def __str__(self):
        return f"{self.bank_account.account_name} - {self.balance_date}"
