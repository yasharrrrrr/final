# __init__.py for accounting
default_app_config = 'accounting.apps.AccountingConfig'
