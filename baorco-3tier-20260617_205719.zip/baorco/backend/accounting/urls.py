from django.urls import path, include
from rest_framework.routers import DefaultRouter
from accounting.views import (
    AccountViewSet, JournalEntryViewSet, InvoiceViewSet, 
    ExpenseViewSet, FinancialReportViewSet, BankAccountViewSet
)

router = DefaultRouter()
router.register(r'accounts', AccountViewSet, basename='account')
router.register(r'journal-entries', JournalEntryViewSet, basename='journal-entry')
router.register(r'invoices', InvoiceViewSet, basename='invoice')
router.register(r'expenses', ExpenseViewSet, basename='expense')
router.register(r'financial-reports', FinancialReportViewSet, basename='financial-report')
router.register(r'bank-accounts', BankAccountViewSet, basename='bank-account')

urlpatterns = [
    path('', include(router.urls)),
]
