from django.core.management.base import BaseCommand
from accounting.models import Account

class Command(BaseCommand):
    help = 'Initialize chart of accounts'

    def handle(self, *args, **options):
        accounts = [
            # Assets
            {'account_number': '1000', 'name': 'نقد و معادل‌های نقد', 'account_type': 'asset'},
            {'account_number': '1100', 'name': 'حساب‌های بانکی', 'account_type': 'asset'},
            {'account_number': '1200', 'name': 'حساب‌های دریافتنی', 'account_type': 'asset'},
            {'account_number': '1300', 'name': 'موجودی محصولات', 'account_type': 'asset'},
            
            # Liabilities
            {'account_number': '2000', 'name': 'حساب‌های پرداختنی', 'account_type': 'liability'},
            {'account_number': '2100', 'name': 'وام‌های کوتاه‌مدت', 'account_type': 'liability'},
            
            # Equity
            {'account_number': '3000', 'name': 'سرمایه', 'account_type': 'equity'},
            {'account_number': '3100', 'name': 'درآمد‌های انباشته', 'account_type': 'equity'},
            
            # Revenue
            {'account_number': '4000', 'name': 'درآمد فروش محصولات', 'account_type': 'revenue'},
            {'account_number': '4100', 'name': 'درآمد خدمات', 'account_type': 'revenue'},
            
            # Expenses
            {'account_number': '5000', 'name': 'بهای تمام شده محصولات', 'account_type': 'expense'},
            {'account_number': '5100', 'name': 'حقوق و دستمزد', 'account_type': 'expense'},
            {'account_number': '5200', 'name': 'اجاره', 'account_type': 'expense'},
            {'account_number': '5300', 'name': 'برق و آب', 'account_type': 'expense'},
            {'account_number': '5400', 'name': 'بازاریابی و تبلیغات', 'account_type': 'expense'},
            {'account_number': '5500', 'name': 'حمل و نقل', 'account_type': 'expense'},
            {'account_number': '5600', 'name': 'هزینه‌های اداری', 'account_type': 'expense'},
        ]
        
        for account_data in accounts:
            account, created = Account.objects.get_or_create(
                account_number=account_data['account_number'],
                defaults=account_data
            )
            
            if created:
                self.stdout.write(
                    self.style.SUCCESS(f"Account '{account.name}' created successfully")
                )
            else:
                self.stdout.write(
                    self.style.WARNING(f"Account '{account.name}' already exists")
                )
        
        self.stdout.write(self.style.SUCCESS('All accounts initialized'))
