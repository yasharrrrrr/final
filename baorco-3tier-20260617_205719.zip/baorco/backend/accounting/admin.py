from django.contrib import admin
from accounting.models import Account, JournalEntry, JournalLine, Invoice, Expense, FinancialReport, BankAccount, DailyBalance

@admin.register(Account)
class AccountAdmin(admin.ModelAdmin):
    list_display = ('account_number', 'name', 'account_type', 'balance', 'is_active')
    list_filter = ('account_type', 'is_active')
    search_fields = ('account_number', 'name')
    readonly_fields = ('created_at', 'updated_at')

class JournalLineInline(admin.TabularInline):
    model = JournalLine
    extra = 2

@admin.register(JournalEntry)
class JournalEntryAdmin(admin.ModelAdmin):
    list_display = ('entry_number', 'entry_date', 'description', 'is_posted', 'created_at')
    list_filter = ('is_posted', 'entry_date')
    search_fields = ('entry_number', 'description', 'reference_id')
    readonly_fields = ('entry_number', 'created_at', 'updated_at')
    inlines = [JournalLineInline]

@admin.register(JournalLine)
class JournalLineAdmin(admin.ModelAdmin):
    list_display = ('journal_entry', 'account', 'transaction_type', 'amount')
    list_filter = ('transaction_type', 'journal_entry__entry_date')
    search_fields = ('journal_entry__entry_number', 'account__name')

@admin.register(Invoice)
class InvoiceAdmin(admin.ModelAdmin):
    list_display = ('invoice_number', 'customer', 'issue_date', 'due_date', 'status', 'total')
    list_filter = ('status', 'issue_date', 'due_date')
    search_fields = ('invoice_number', 'customer__username', 'order__order_number')
    readonly_fields = ('invoice_number', 'created_at', 'updated_at')

@admin.register(Expense)
class ExpenseAdmin(admin.ModelAdmin):
    list_display = ('expense_number', 'category', 'amount', 'is_approved', 'expense_date')
    list_filter = ('category', 'is_approved', 'expense_date')
    search_fields = ('expense_number', 'description')
    readonly_fields = ('expense_number', 'created_at', 'updated_at')

@admin.register(FinancialReport)
class FinancialReportAdmin(admin.ModelAdmin):
    list_display = ('report_type', 'period_start', 'period_end', 'generated_by', 'created_at')
    list_filter = ('report_type', 'period_start')
    search_fields = ('report_type',)
    readonly_fields = ('created_at', 'data')

@admin.register(BankAccount)
class BankAccountAdmin(admin.ModelAdmin):
    list_display = ('account_name', 'bank_name', 'account_number', 'balance', 'is_active')
    list_filter = ('bank_name', 'is_active')
    search_fields = ('account_name', 'account_number', 'iban')
    readonly_fields = ('created_at', 'updated_at')

@admin.register(DailyBalance)
class DailyBalanceAdmin(admin.ModelAdmin):
    list_display = ('bank_account', 'balance_date', 'opening_balance', 'closing_balance')
    list_filter = ('balance_date', 'bank_account')
    search_fields = ('bank_account__account_name',)
    readonly_fields = ('created_at',)
