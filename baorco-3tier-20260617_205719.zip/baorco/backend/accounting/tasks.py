from celery import shared_task
from django.utils import timezone
from orders.models import Order
from accounting.models import Invoice, JournalEntry, JournalLine, Account
from notifications.services import sms_service, email_service
import logging

logger = logging.getLogger('baorco')

@shared_task
def create_invoice(order_id):
    """
    Create invoice for an order
    """
    try:
        order = Order.objects.get(id=order_id)
        
        # Calculate tax
        tax_amount = order.subtotal * 0.09
        
        invoice = Invoice.objects.create(
            order=order,
            customer=order.customer,
            issue_date=timezone.now().date(),
            due_date=(timezone.now() + timezone.timedelta(days=30)).date(),
            subtotal=order.subtotal,
            tax_amount=tax_amount,
            discount_amount=order.discount_amount,
            total=order.total,
            remaining_amount=order.total,
            status='issued'
        )
        
        logger.info(f"Invoice {invoice.invoice_number} created for order {order.order_number}")
        return invoice.id
    except Exception as e:
        logger.error(f"Error creating invoice for order {order_id}: {str(e)}")
        return None


@shared_task
def create_journal_entries(order_id):
    """
    Create accounting journal entries for an order
    """
    try:
        order = Order.objects.get(id=order_id)
        
        # Get or create accounts
        revenue_account = Account.objects.get_or_create(
            account_type='revenue',
            defaults={
                'account_number': '4001',
                'name': 'محصولات فروخته شده',
            }
        )[0]
        
        receivable_account = Account.objects.get_or_create(
            account_type='asset',
            defaults={
                'account_number': '1200',
                'name': 'حساب‌های دریافتنی',
            }
        )[0]
        
        # Create journal entry
        journal_entry = JournalEntry.objects.create(
            entry_date=order.created_at.date(),
            description=f"Order {order.order_number} - {order.customer.get_full_name()}",
            created_by=None,
            reference_type='order',
            reference_id=order.id,
            is_posted=True
        )
        
        # Debit: Receivable Account
        JournalLine.objects.create(
            journal_entry=journal_entry,
            account=receivable_account,
            transaction_type='debit',
            amount=order.total
        )
        receivable_account.balance += order.total
        receivable_account.save()
        
        # Credit: Revenue Account
        JournalLine.objects.create(
            journal_entry=journal_entry,
            account=revenue_account,
            transaction_type='credit',
            amount=order.total
        )
        revenue_account.balance -= order.total
        revenue_account.save()
        
        logger.info(f"Journal entries created for order {order.order_number}")
        return journal_entry.id
    except Exception as e:
        logger.error(f"Error creating journal entries for order {order_id}: {str(e)}")
        return None


@shared_task
def send_payment_reminder():
    """
    Send payment reminders for overdue installments
    """
    from orders.models import InstallmentPlan
    
    try:
        overdue_plans = InstallmentPlan.objects.filter(
            status='pending',
            due_date__lt=timezone.now().date()
        )
        
        for plan in overdue_plans:
            sms_service.send_payment_reminder(plan)
            plan.status = 'overdue'
            plan.save()
        
        logger.info(f"Payment reminders sent for {overdue_plans.count()} overdue installments")
    except Exception as e:
        logger.error(f"Error sending payment reminders: {str(e)}")


@shared_task
def update_daily_balances():
    """
    Update daily balance snapshots for bank accounts
    """
    from accounting.models import BankAccount, DailyBalance
    
    try:
        today = timezone.now().date()
        
        for bank_account in BankAccount.objects.filter(is_active=True):
            # Get previous day's balance
            previous_balance = DailyBalance.objects.filter(
                bank_account=bank_account,
                balance_date__lt=today
            ).order_by('-balance_date').first()
            
            opening_balance = previous_balance.closing_balance if previous_balance else bank_account.balance
            
            DailyBalance.objects.get_or_create(
                bank_account=bank_account,
                balance_date=today,
                defaults={
                    'opening_balance': opening_balance,
                    'closing_balance': bank_account.balance,
                }
            )
        
        logger.info("Daily balances updated")
    except Exception as e:
        logger.error(f"Error updating daily balances: {str(e)}")


@shared_task
def cleanup_expired_otps():
    """
    Delete expired OTP codes
    """
    from notifications.models import OTPCode
    
    try:
        expired_otps = OTPCode.objects.filter(
            status='active',
            expires_at__lt=timezone.now()
        )
        count = expired_otps.count()
        expired_otps.delete()
        
        logger.info(f"Deleted {count} expired OTP codes")
    except Exception as e:
        logger.error(f"Error cleaning up expired OTPs: {str(e)}")


@shared_task
def process_pending_payments():
    """
    Process pending payments and update payment status
    """
    try:
        from orders.models import Payment
        
        pending_payments = Payment.objects.filter(status='pending')
        
        for payment in pending_payments:
            # Check payment status with gateway
            # This is a placeholder - actual implementation depends on payment gateway
            logger.info(f"Processing payment {payment.id} for order {payment.order.order_number}")
    
    except Exception as e:
        logger.error(f"Error processing pending payments: {str(e)}")


@shared_task
def generate_daily_reports():
    """
    Generate daily sales and accounting reports
    """
    try:
        from django.db.models import Sum, Count
        from orders.models import Order
        
        today = timezone.now().date()
        
        daily_stats = Order.objects.filter(
            created_at__date=today,
            status='delivered'
        ).aggregate(
            total_orders=Count('id'),
            total_revenue=Sum('total'),
            total_items=Sum('items__quantity')
        )
        
        logger.info(f"Daily report for {today}: {daily_stats}")
    except Exception as e:
        logger.error(f"Error generating daily reports: {str(e)}")
