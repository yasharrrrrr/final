from rest_framework import viewsets, status, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from django.utils import timezone
from django.db.models import Sum, Count
from accounting.models import (
    Account, JournalEntry, JournalLine, Invoice, Expense, 
    FinancialReport, BankAccount, DailyBalance
)
from orders.models import Order
import logging

logger = logging.getLogger('baorco')

class AccountViewSet(viewsets.ModelViewSet):
    """
    ViewSet for chart of accounts management
    """
    queryset = Account.objects.all()
    permission_classes = [permissions.IsAuthenticated]
    
    def check_admin_permission(self, request):
        if not request.user.is_admin or not request.user.admin_profile.can_manage_accounting:
            raise permissions.PermissionDenied('شما اجازه دسترسی ندارید')
    
    def get_queryset(self):
        queryset = super().get_queryset()
        if not request.user.is_admin:
            raise permissions.PermissionDenied('شما اجازه دسترسی ندارید')
        return queryset
    
    def create(self, request, *args, **kwargs):
        self.check_admin_permission(request)
        return super().create(request, *args, **kwargs)
    
    def update(self, request, *args, **kwargs):
        self.check_admin_permission(request)
        return super().update(request, *args, **kwargs)
    
    def destroy(self, request, *args, **kwargs):
        self.check_admin_permission(request)
        return super().destroy(request, *args, **kwargs)


class JournalEntryViewSet(viewsets.ModelViewSet):
    """
    ViewSet for general journal entry management
    """
    queryset = JournalEntry.objects.all()
    permission_classes = [permissions.IsAuthenticated]
    
    def check_admin_permission(self, request):
        if not request.user.is_admin or not request.user.admin_profile.can_manage_accounting:
            raise permissions.PermissionDenied('شما اجازه دسترسی ندارید')
    
    def create(self, request, *args, **kwargs):
        self.check_admin_permission(request)
        
        # Create journal entry
        journal_entry = JournalEntry.objects.create(
            entry_date=request.data.get('entry_date', timezone.now().date()),
            description=request.data.get('description'),
            created_by=request.user,
            reference_type=request.data.get('reference_type', 'other')
        )
        
        # Create journal lines
        lines_data = request.data.get('lines', [])
        total_debit = 0
        total_credit = 0
        
        for line_data in lines_data:
            account_id = line_data.get('account_id')
            transaction_type = line_data.get('transaction_type')  # 'debit' or 'credit'
            amount = float(line_data.get('amount', 0))
            
            account = Account.objects.get(id=account_id)
            
            JournalLine.objects.create(
                journal_entry=journal_entry,
                account=account,
                transaction_type=transaction_type,
                amount=amount,
                description=line_data.get('description')
            )
            
            # Update account balance
            if transaction_type == 'debit':
                account.balance += amount
                total_debit += amount
            else:
                account.balance -= amount
                total_credit += amount
            
            account.save()
        
        # Validate that debits equal credits
        if total_debit != total_credit:
            journal_entry.delete()
            return Response(
                {'error': 'مجموع بدهکار و بستانکار برابر نیست'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        return Response(
            {'id': journal_entry.id, 'entry_number': journal_entry.entry_number},
            status=status.HTTP_201_CREATED
        )
    
    @action(detail=True, methods=['post'])
    def post(self, request, pk=None):
        """Post journal entry"""
        self.check_admin_permission(request)
        
        journal_entry = self.get_object()
        if journal_entry.is_posted:
            return Response(
                {'error': 'این ورود قبلاً پست شده است'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        journal_entry.is_posted = True
        journal_entry.save()
        
        return Response({'message': 'ورود پست شد'})


class InvoiceViewSet(viewsets.ModelViewSet):
    """
    ViewSet for invoice management
    """
    queryset = Invoice.objects.all()
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        if self.request.user.is_admin:
            return Invoice.objects.all()
        return Invoice.objects.filter(customer=self.request.user)
    
    def check_admin_permission(self, request):
        if not request.user.is_admin or not request.user.admin_profile.can_manage_accounting:
            raise permissions.PermissionDenied('شما اجازه دسترسی ندارید')
    
    @action(detail=True, methods=['post'])
    def mark_as_paid(self, request, pk=None):
        """Mark invoice as paid"""
        invoice = self.get_object()
        
        if not request.user.is_admin:
            raise permissions.PermissionDenied('شما اجازه دسترسی ندارید')
        
        paid_amount = float(request.data.get('paid_amount', 0))
        
        if paid_amount <= 0:
            return Response(
                {'error': 'مبلغ پرداختی باید بیشتر از صفر باشد'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        invoice.paid_amount += paid_amount
        invoice.remaining_amount = invoice.total - invoice.paid_amount
        
        if invoice.paid_amount >= invoice.total:
            invoice.status = 'paid'
        else:
            invoice.status = 'partially_paid'
        
        invoice.save()
        
        return Response({'message': 'فاکتور بروزرسانی شد'})
    
    @action(detail=True, methods=['post'])
    def send(self, request, pk=None):
        """Send invoice to customer"""
        invoice = self.get_object()
        
        if not request.user.is_admin:
            raise permissions.PermissionDenied('شما اجازه دسترسی ندارید')
        
        invoice.status = 'sent'
        invoice.save()
        
        # TODO: Send email to customer
        
        return Response({'message': 'فاکتور ارسال شد'})


class ExpenseViewSet(viewsets.ModelViewSet):
    """
    ViewSet for expense management
    """
    queryset = Expense.objects.all()
    permission_classes = [permissions.IsAuthenticated]
    
    def check_admin_permission(self, request):
        if not request.user.is_admin or not request.user.admin_profile.can_manage_accounting:
            raise permissions.PermissionDenied('شما اجازه دسترسی ندارید')
    
    def create(self, request, *args, **kwargs):
        self.check_admin_permission(request)
        
        expense = Expense.objects.create(
            category=request.data.get('category'),
            description=request.data.get('description'),
            amount=float(request.data.get('amount')),
            payment_method=request.data.get('payment_method'),
            expense_date=request.data.get('expense_date', timezone.now().date()),
            account_id=request.data.get('account_id'),
            submitted_by=request.user
        )
        
        return Response(
            {'id': expense.id, 'expense_number': expense.expense_number},
            status=status.HTTP_201_CREATED
        )
    
    @action(detail=True, methods=['post'])
    def approve(self, request, pk=None):
        """Approve expense"""
        self.check_admin_permission(request)
        
        expense = self.get_object()
        if expense.is_approved:
            return Response(
                {'error': 'این هزینه قبلاً تایید شده است'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        expense.is_approved = True
        expense.approved_by = request.user
        expense.save()
        
        # Create journal entry for expense
        account = Account.objects.get(account_type='expense', name__icontains=expense.get_category_display())
        
        JournalEntry.objects.create(
            entry_date=expense.expense_date,
            description=f"Expense: {expense.description}",
            created_by=request.user,
            reference_type='other',
            is_posted=True
        )
        
        return Response({'message': 'هزینه تایید شد'})


class FinancialReportViewSet(viewsets.ReadOnlyModelViewSet):
    """
    ViewSet for financial reports
    """
    queryset = FinancialReport.objects.all()
    permission_classes = [permissions.IsAuthenticated]
    
    def check_admin_permission(self, request):
        if not request.user.is_admin or not request.user.admin_profile.can_manage_accounting:
            raise permissions.PermissionDenied('شما اجازه دسترسی ندارید')
    
    def get_queryset(self):
        self.check_admin_permission(self.request)
        return super().get_queryset()
    
    @action(detail=False, methods=['post'])
    def generate_income_statement(self, request):
        """Generate income statement"""
        self.check_admin_permission(request)
        
        period_start = timezone.datetime.strptime(
            request.data.get('period_start'), '%Y-%m-%d'
        ).date()
        period_end = timezone.datetime.strptime(
            request.data.get('period_end'), '%Y-%m-%d'
        ).date()
        
        # Calculate revenues
        revenue_orders = Order.objects.filter(
            created_at__date__gte=period_start,
            created_at__date__lte=period_end,
            status='delivered'
        ).aggregate(total=Sum('total'))['total'] or 0
        
        # Calculate expenses
        expenses = Expense.objects.filter(
            expense_date__gte=period_start,
            expense_date__lte=period_end,
            is_approved=True
        ).aggregate(total=Sum('amount'))['total'] or 0
        
        net_income = revenue_orders - expenses
        
        data = {
            'revenue': revenue_orders,
            'expenses': expenses,
            'net_income': net_income
        }
        
        report = FinancialReport.objects.create(
            report_type='income_statement',
            period_start=period_start,
            period_end=period_end,
            data=data,
            generated_by=request.user
        )
        
        return Response({
            'id': report.id,
            'report_type': 'income_statement',
            'period_start': period_start,
            'period_end': period_end,
            'data': data
        }, status=status.HTTP_201_CREATED)
    
    @action(detail=False, methods=['post'])
    def generate_balance_sheet(self, request):
        """Generate balance sheet"""
        self.check_admin_permission(request)
        
        period_date = timezone.datetime.strptime(
            request.data.get('period_date'), '%Y-%m-%d'
        ).date()
        
        # Calculate account balances
        assets = Account.objects.filter(
            account_type='asset'
        ).aggregate(total=Sum('balance'))['total'] or 0
        
        liabilities = Account.objects.filter(
            account_type='liability'
        ).aggregate(total=Sum('balance'))['total'] or 0
        
        equity = Account.objects.filter(
            account_type='equity'
        ).aggregate(total=Sum('balance'))['total'] or 0
        
        data = {
            'assets': assets,
            'liabilities': liabilities,
            'equity': equity,
            'total_liabilities_equity': liabilities + equity
        }
        
        report = FinancialReport.objects.create(
            report_type='balance_sheet',
            period_start=period_date,
            period_end=period_date,
            data=data,
            generated_by=request.user
        )
        
        return Response({
            'id': report.id,
            'report_type': 'balance_sheet',
            'period_date': period_date,
            'data': data
        }, status=status.HTTP_201_CREATED)


class BankAccountViewSet(viewsets.ModelViewSet):
    """
    ViewSet for bank account management
    """
    queryset = BankAccount.objects.all()
    permission_classes = [permissions.IsAuthenticated]
    
    def check_admin_permission(self, request):
        if not request.user.is_admin or not request.user.admin_profile.can_manage_accounting:
            raise permissions.PermissionDenied('شما اجازه دسترسی ندارید')
    
    def create(self, request, *args, **kwargs):
        self.check_admin_permission(request)
        return super().create(request, *args, **kwargs)
    
    def update(self, request, *args, **kwargs):
        self.check_admin_permission(request)
        return super().update(request, *args, **kwargs)
    
    def destroy(self, request, *args, **kwargs):
        self.check_admin_permission(request)
        return super().destroy(request, *args, **kwargs)
