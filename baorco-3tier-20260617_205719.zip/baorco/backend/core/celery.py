import os
from celery import Celery
from celery.schedules import crontab

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')

app = Celery('baorco')
app.config_from_object('django.conf:settings', namespace='CELERY')
app.autodiscover_tasks()

# Celery Beat Schedule
app.conf.beat_schedule = {
    'send-payment-reminders': {
        'task': 'accounting.tasks.send_payment_reminder',
        'schedule': crontab(hour=10, minute=0),  # Daily at 10:00 AM
    },
    'update-daily-balances': {
        'task': 'accounting.tasks.update_daily_balances',
        'schedule': crontab(hour=23, minute=59),  # Daily at 11:59 PM
    },
    'cleanup-expired-otps': {
        'task': 'notifications.tasks.cleanup_expired_otps',
        'schedule': crontab(minute=0),  # Every hour
    },
    'generate-daily-reports': {
        'task': 'accounting.tasks.generate_daily_reports',
        'schedule': crontab(hour=0, minute=1),  # Daily at 00:01 AM
    },
}
