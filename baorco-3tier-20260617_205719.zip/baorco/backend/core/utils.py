import re
import logging
from datetime import datetime, timedelta
from django.utils import timezone
from django.core.mail import send_mail
from django.conf import settings

logger = logging.getLogger('baorco')

class PhoneValidator:
    """
    Validate Iranian phone numbers
    """
    @staticmethod
    def validate(phone):
        """
        Validate phone number format
        Returns: bool
        """
        pattern = r'^(\+98|0)?9\d{9}$'
        return bool(re.match(pattern, phone))
    
    @staticmethod
    def normalize(phone):
        """
        Normalize phone number to standard format
        Returns: str (e.g., 989123456789)
        """
        phone = phone.replace('-', '').replace(' ', '')
        if phone.startswith('0098'):
            phone = phone[2:]
        elif phone.startswith('+98'):
            phone = '98' + phone[3:]
        elif phone.startswith('0'):
            phone = '98' + phone[1:]
        elif not phone.startswith('98'):
            phone = '98' + phone
        return phone

class NationalIDValidator:
    """
    Validate Iranian national ID
    """
    @staticmethod
    def validate(national_id):
        """
        Validate national ID format and checksum
        Returns: bool
        """
        if not national_id or len(national_id) != 10:
            return False
        
        if not national_id.isdigit():
            return False
        
        # Calculate checksum
        check_digit = int(national_id[9])
        total = sum(int(national_id[i]) * (10 - i) for i in range(9))
        remainder = total % 11
        
        if remainder < 2:
            return check_digit == remainder
        else:
            return check_digit == 11 - remainder

class EmailValidator:
    """
    Validate email addresses
    """
    @staticmethod
    def validate(email):
        """
        Validate email format
        Returns: bool
        """
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(pattern, email))

class PriceFormatter:
    """
    Format prices for Persian language display
    """
    @staticmethod
    def format_price(price, currency='تومان'):
        """
        Format price with currency
        Returns: str (e.g., "1,234,567 تومان")
        """
        return f"{int(price):,} {currency}"
    
    @staticmethod
    def persian_numbers(number):
        """
        Convert English numbers to Persian
        Returns: str
        """
        persian_digits = '۰۱۲۳۴۵۶۷۸۹'
        english_digits = '0123456789'
        
        for i, digit in enumerate(english_digits):
            number = str(number).replace(digit, persian_digits[i])
        return number

class DateConverter:
    """
    Convert between Gregorian and Shamsi (Persian) dates
    """
    @staticmethod
    def gregorian_to_shamsi(gregorian_date):
        """
        Convert Gregorian date to Shamsi
        Returns: str (e.g., "1402/10/25")
        """
        try:
            from jdatetime import date as jdate
            shamsi_date = jdate.fromgregorian(date=gregorian_date)
            return shamsi_date.strftime('%Y/%m/%d')
        except:
            # Fallback if jdatetime not available
            g_y, g_m, g_d = gregorian_date.year, gregorian_date.month, gregorian_date.day
            
            if g_m > 2:
                jy = g_y - 1979
            else:
                jy = g_y - 1980
            
            if g_m > 2:
                gm = g_m - 3
            else:
                gm = g_m + 9
            
            jd = ((g_d - 1) + (31 * gm - int(gm / 2)) + 1)
            
            return f"{jy}/{int(gm/3.1)+1:02d}/{jd:02d}"
    
    @staticmethod
    def shamsi_to_gregorian(shamsi_date_str):
        """
        Convert Shamsi date string to Gregorian
        Returns: datetime.date
        """
        try:
            from jdatetime import date as jdate
            jy, jm, jd = map(int, shamsi_date_str.split('/'))
            return jdate(jy, jm, jd).togregorian()
        except:
            # Fallback calculation
            jy, jm, jd = map(int, shamsi_date_str.split('/'))
            gy = jy + 1979 if jm > 2 else jy + 1980
            gm = jm + 3 if jm < 10 else jm - 9
            gd = jd
            return datetime(gy, gm, gd).date()

class OTPGenerator:
    """
    Generate and manage OTP codes
    """
    @staticmethod
    def generate():
        """
        Generate random 6-digit OTP
        Returns: str
        """
        import random
        return ''.join(random.choices('0123456789', k=6))
    
    @staticmethod
    def get_expiry_time(minutes=2):
        """
        Get OTP expiry time
        Returns: datetime
        """
        return timezone.now() + timedelta(minutes=minutes)

class OrderNumberGenerator:
    """
    Generate unique order numbers
    """
    @staticmethod
    def generate():
        """
        Generate unique order number
        Returns: str (e.g., "ORD-20240115-ABC123")
        """
        import uuid
        date_part = timezone.now().strftime('%Y%m%d')
        random_part = uuid.uuid4().hex[:6].upper()
        return f"ORD-{date_part}-{random_part}"

class InvoiceNumberGenerator:
    """
    Generate unique invoice numbers
    """
    @staticmethod
    def generate():
        """
        Generate unique invoice number
        Returns: str (e.g., "INV-20240115-XYZ789")
        """
        import uuid
        date_part = timezone.now().strftime('%Y%m%d')
        random_part = uuid.uuid4().hex[:6].upper()
        return f"INV-{date_part}-{random_part}"

class ExpenseNumberGenerator:
    """
    Generate unique expense numbers
    """
    @staticmethod
    def generate():
        """
        Generate unique expense number
        Returns: str (e.g., "EXP-20240115-DEF456")
        """
        import uuid
        date_part = timezone.now().strftime('%Y%m%d')
        random_part = uuid.uuid4().hex[:6].upper()
        return f"EXP-{date_part}-{random_part}"

class Logger:
    """
    Custom logging utility
    """
    @staticmethod
    def log_action(user, action, details=None):
        """
        Log user action
        """
        message = f"User: {user.username}, Action: {action}"
        if details:
            message += f", Details: {details}"
        logger.info(message)
    
    @staticmethod
    def log_error(action, error):
        """
        Log error
        """
        logger.error(f"Action: {action}, Error: {str(error)}")
    
    @staticmethod
    def log_warning(action, warning):
        """
        Log warning
        """
        logger.warning(f"Action: {action}, Warning: {warning}")

class EmailHelper:
    """
    Helper functions for email operations
    """
    @staticmethod
    def send_email(subject, message, recipient_email):
        """
        Send email
        Returns: bool
        """
        try:
            send_mail(
                subject,
                message,
                settings.EMAIL_HOST_USER,
                [recipient_email],
                fail_silently=False,
            )
            return True
        except Exception as e:
            logger.error(f"Error sending email: {str(e)}")
            return False
