from rest_framework import permissions

class IsAdmin(permissions.BasePermission):
    """
    Permission to check if user is admin
    """
    def has_permission(self, request, view):
        return request.user and request.user.is_authenticated and request.user.is_admin

class IsCustomer(permissions.BasePermission):
    """
    Permission to check if user is customer
    """
    def has_permission(self, request, view):
        return request.user and request.user.is_authenticated and request.user.is_customer

class CanManageProducts(permissions.BasePermission):
    """
    Permission to manage products
    """
    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            return False
        if not request.user.is_admin:
            return False
        return request.user.admin_profile.can_manage_products

class CanManageOrders(permissions.BasePermission):
    """
    Permission to manage orders
    """
    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            return False
        if not request.user.is_admin:
            return False
        return request.user.admin_profile.can_manage_orders

class CanManageAccounting(permissions.BasePermission):
    """
    Permission to manage accounting
    """
    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            return False
        if not request.user.is_admin:
            return False
        return request.user.admin_profile.can_manage_accounting

class CanManageUsers(permissions.BasePermission):
    """
    Permission to manage users
    """
    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            return False
        if not request.user.is_admin:
            return False
        return request.user.admin_profile.can_manage_users

class IsOwner(permissions.BasePermission):
    """
    Permission to check if user is the owner of the object
    """
    def has_object_permission(self, request, view, obj):
        if hasattr(obj, 'customer'):
            return obj.customer == request.user
        if hasattr(obj, 'user'):
            return obj.user == request.user
        return False

class IsOwnerOrAdmin(permissions.BasePermission):
    """
    Permission to check if user is owner or admin
    """
    def has_object_permission(self, request, view, obj):
        if request.user.is_admin:
            return True
        if hasattr(obj, 'customer'):
            return obj.customer == request.user
        if hasattr(obj, 'user'):
            return obj.user == request.user
        return False
