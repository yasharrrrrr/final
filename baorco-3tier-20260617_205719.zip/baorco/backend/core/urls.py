from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import TokenRefreshView
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView

# Import ViewSets
from accounts.views import (
    RegisterView, LoginView, PhoneVerificationView, OTPVerificationView,
    UserViewSet, AdminViewSet, CustomerViewSet, AdminProfileViewSet, CustomerProfileViewSet
)
from products.views import CategoryViewSet, ProductViewSet, WishlistViewSet, DiscountViewSet
from orders.views import CartViewSet, OrderViewSet, PaymentViewSet, ShipmentTrackingViewSet
from accounting.views import (
    AccountViewSet, JournalEntryViewSet, InvoiceViewSet, ExpenseViewSet,
    FinancialReportViewSet, BankAccountViewSet
)

# Create router
router = DefaultRouter()

# Register ViewSets
router.register(r'users', UserViewSet, basename='user')
router.register(r'admins', AdminViewSet, basename='admin')
router.register(r'customers', CustomerViewSet, basename='customer')
router.register(r'admin-profiles', AdminProfileViewSet, basename='admin-profile')
router.register(r'customer-profiles', CustomerProfileViewSet, basename='customer-profile')

router.register(r'categories', CategoryViewSet, basename='category')
router.register(r'products', ProductViewSet, basename='product')
router.register(r'wishlist', WishlistViewSet, basename='wishlist')
router.register(r'discounts', DiscountViewSet, basename='discount')

router.register(r'cart', CartViewSet, basename='cart')
router.register(r'orders', OrderViewSet, basename='order')
router.register(r'payments', PaymentViewSet, basename='payment')
router.register(r'shipments', ShipmentTrackingViewSet, basename='shipment')

router.register(r'accounts', AccountViewSet, basename='account')
router.register(r'journal-entries', JournalEntryViewSet, basename='journal-entry')
router.register(r'invoices', InvoiceViewSet, basename='invoice')
router.register(r'expenses', ExpenseViewSet, basename='expense')
router.register(r'financial-reports', FinancialReportViewSet, basename='financial-report')
router.register(r'bank-accounts', BankAccountViewSet, basename='bank-account')

urlpatterns = [
    # Admin
    path('admin/', admin.site.urls),
    
    # API Documentation
    path('api/schema/', SpectacularAPIView.as_view(), name='schema'),
    path('api/docs/', SpectacularSwaggerView.as_view(url_name='schema'), name='swagger-ui'),
    
    # Authentication endpoints
    path('api/auth/register/', RegisterView.as_view(), name='register'),
    path('api/auth/login/', LoginView.as_view(), name='login'),
    path('api/auth/token/refresh/', TokenRefreshView.as_view(), name='token-refresh'),
    path('api/auth/phone-verification/', PhoneVerificationView.as_view(), name='phone-verification'),
    path('api/auth/otp-verification/', OTPVerificationView.as_view(), name='otp-verification'),
    
    # API Routes
    path('api/', include(router.urls)),
]

# Serve media files in development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
