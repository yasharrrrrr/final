from django.contrib import admin
from orders.models import Cart, CartItem, Order, OrderItem, Payment, InstallmentPlan, ShipmentTracking

@admin.register(Cart)
class CartAdmin(admin.ModelAdmin):
    list_display = ('customer', 'total_items', 'total_price', 'updated_at')
    search_fields = ('customer__username', 'customer__email')
    readonly_fields = ('created_at', 'updated_at', 'total_price', 'total_items')

@admin.register(CartItem)
class CartItemAdmin(admin.ModelAdmin):
    list_display = ('cart', 'product', 'quantity', 'price', 'total_price')
    list_filter = ('created_at',)
    search_fields = ('cart__customer__username', 'product__name')

class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0

class InstallmentPlanInline(admin.TabularInline):
    model = InstallmentPlan
    extra = 0

class ShipmentTrackingInline(admin.TabularInline):
    model = ShipmentTracking
    extra = 1

@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('order_number', 'customer', 'status', 'payment_status', 'total', 'created_at')
    list_filter = ('status', 'payment_status', 'payment_method', 'is_installment', 'created_at')
    search_fields = ('order_number', 'customer__username', 'customer__email')
    readonly_fields = ('order_number', 'created_at', 'updated_at', 'shipped_at', 'delivered_at')
    inlines = [OrderItemInline, InstallmentPlanInline, ShipmentTrackingInline]
    
    fieldsets = (
        ('Order Info', {
            'fields': ('order_number', 'customer', 'status', 'created_at', 'updated_at')
        }),
        ('Shipping', {
            'fields': ('shipping_address', 'shipping_city', 'shipping_postal_code', 'shipping_phone', 'tracking_number', 'estimated_delivery')
        }),
        ('Payment', {
            'fields': ('payment_method', 'payment_status', 'is_installment', 'installment_months', 'monthly_payment')
        }),
        ('Pricing', {
            'fields': ('subtotal', 'tax', 'shipping_cost', 'discount_amount', 'discount_code', 'total')
        }),
        ('Notes', {
            'fields': ('notes', 'admin_notes')
        }),
        ('Shipment', {
            'fields': ('shipped_at', 'delivered_at')
        }),
    )
    
    actions = ['mark_as_confirmed', 'mark_as_shipped', 'mark_as_delivered']
    
    def mark_as_confirmed(self, request, queryset):
        queryset.update(status='confirmed')
    mark_as_confirmed.short_description = "تأیید سفارش‌های انتخاب شده"
    
    def mark_as_shipped(self, request, queryset):
        queryset.update(status='shipped')
    mark_as_shipped.short_description = "ارسال سفارش‌های انتخاب شده"
    
    def mark_as_delivered(self, request, queryset):
        from django.utils import timezone
        queryset.update(status='delivered', delivered_at=timezone.now())
    mark_as_delivered.short_description = "تحویل سفارش‌های انتخاب شده"

@admin.register(OrderItem)
class OrderItemAdmin(admin.ModelAdmin):
    list_display = ('order', 'product', 'quantity', 'price', 'total_price')
    list_filter = ('order__created_at',)
    search_fields = ('order__order_number', 'product__name')

@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ('order', 'amount', 'status', 'payment_gateway', 'payment_date')
    list_filter = ('status', 'payment_gateway', 'payment_date')
    search_fields = ('order__order_number', 'transaction_id')
    readonly_fields = ('created_at', 'updated_at')

@admin.register(InstallmentPlan)
class InstallmentPlanAdmin(admin.ModelAdmin):
    list_display = ('order', 'payment_number', 'amount', 'due_date', 'status')
    list_filter = ('status', 'due_date')
    search_fields = ('order__order_number',)

@admin.register(ShipmentTracking)
class ShipmentTrackingAdmin(admin.ModelAdmin):
    list_display = ('order', 'status', 'location', 'updated_at')
    list_filter = ('status', 'updated_at')
    search_fields = ('order__order_number',)
