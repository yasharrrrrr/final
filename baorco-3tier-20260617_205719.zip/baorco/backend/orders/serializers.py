from rest_framework import serializers
from orders.models import Cart, CartItem, Order, OrderItem, Payment, InstallmentPlan, ShipmentTracking

class CartItemSerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(source='product.name', read_only=True)
    product_image = serializers.SerializerMethodField()
    
    class Meta:
        model = CartItem
        fields = ['id', 'product', 'product_name', 'product_image', 'quantity', 'price', 'total_price']
        read_only_fields = ['id', 'product_name', 'total_price']
    
    def get_product_image(self, obj):
        request = self.context.get('request')
        if obj.product.image and hasattr(obj.product.image, 'url'):
            return request.build_absolute_uri(obj.product.image.url) if request else obj.product.image.url
        return None


class CartSerializer(serializers.ModelSerializer):
    items = CartItemSerializer(many=True, read_only=True)
    
    class Meta:
        model = Cart
        fields = ['id', 'items', 'total_price', 'total_items', 'created_at', 'updated_at']
        read_only_fields = ['id', 'total_price', 'total_items', 'created_at', 'updated_at']


class OrderItemSerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(source='product.name', read_only=True)
    product_image = serializers.SerializerMethodField()
    
    class Meta:
        model = OrderItem
        fields = ['id', 'product', 'product_name', 'product_image', 'quantity', 'price', 'discount', 'total_price']
        read_only_fields = ['id', 'product_name', 'total_price']
    
    def get_product_image(self, obj):
        request = self.context.get('request')
        if obj.product and obj.product.image and hasattr(obj.product.image, 'url'):
            return request.build_absolute_uri(obj.product.image.url) if request else obj.product.image.url
        return None


class InstallmentPlanSerializer(serializers.ModelSerializer):
    class Meta:
        model = InstallmentPlan
        fields = ['id', 'order', 'payment_number', 'amount', 'due_date', 'status', 'paid_date', 'is_overdue']
        read_only_fields = ['id', 'is_overdue']


class ShipmentTrackingSerializer(serializers.ModelSerializer):
    class Meta:
        model = ShipmentTracking
        fields = ['id', 'order', 'status', 'location', 'description', 'updated_at']
        read_only_fields = ['id']


class OrderListSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(source='customer.get_full_name', read_only=True)
    
    class Meta:
        model = Order
        fields = ['id', 'order_number', 'customer_name', 'status', 'payment_status', 
                  'total', 'created_at', 'updated_at']
        read_only_fields = ['id', 'order_number', 'customer_name', 'created_at', 'updated_at']


class OrderDetailSerializer(serializers.ModelSerializer):
    items = OrderItemSerializer(many=True, read_only=True)
    installment_plans = InstallmentPlanSerializer(many=True, read_only=True)
    shipment_tracking = ShipmentTrackingSerializer(many=True, read_only=True)
    customer_name = serializers.CharField(source='customer.get_full_name', read_only=True)
    discount_code = serializers.CharField(source='discount_code.code', read_only=True)
    
    class Meta:
        model = Order
        fields = ['id', 'order_number', 'customer_name', 'shipping_address', 
                  'shipping_city', 'shipping_postal_code', 'shipping_phone', 
                  'status', 'payment_status', 'payment_method', 'subtotal', 'tax', 
                  'shipping_cost', 'discount_amount', 'discount_code', 'total', 
                  'is_installment', 'installment_months', 'monthly_payment', 
                  'notes', 'admin_notes', 'tracking_number', 'estimated_delivery', 
                  'items', 'installment_plans', 'shipment_tracking', 'created_at', 'updated_at']
        read_only_fields = ['id', 'order_number', 'customer_name', 'created_at', 'updated_at']


class OrderCreateSerializer(serializers.ModelSerializer):
    items = CartItemSerializer(many=True, write_only=True)
    
    class Meta:
        model = Order
        fields = ['shipping_address', 'shipping_city', 'shipping_postal_code', 
                  'shipping_phone', 'payment_method', 'is_installment', 
                  'installment_months', 'discount_code', 'notes', 'items']
    
    def create(self, validated_data):
        items_data = validated_data.pop('items', [])
        order = Order.objects.create(**validated_data)
        
        for item_data in items_data:
            OrderItem.objects.create(order=order, **item_data)
        
        return order


class PaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = ['id', 'order', 'amount', 'status', 'payment_gateway', 
                  'transaction_id', 'reference_id', 'payment_date', 'error_message', 'created_at']
        read_only_fields = ['id', 'transaction_id', 'reference_id', 'payment_date', 'created_at']


class OrderStatusUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields = ['status', 'admin_notes']


class OrderSearchSerializer(serializers.Serializer):
    order_number = serializers.CharField(required=False, allow_blank=True)
    status = serializers.ChoiceField(choices=Order.ORDER_STATUS_CHOICES, required=False)
    payment_status = serializers.ChoiceField(choices=Order.PAYMENT_STATUS_CHOICES, required=False)
    date_from = serializers.DateTimeField(required=False)
    date_to = serializers.DateTimeField(required=False)


class OrderStatisticsSerializer(serializers.Serializer):
    total_orders = serializers.IntegerField()
    pending_orders = serializers.IntegerField()
    completed_orders = serializers.IntegerField()
    cancelled_orders = serializers.IntegerField()
    total_revenue = serializers.DecimalField(max_digits=15, decimal_places=2)
    average_order_value = serializers.DecimalField(max_digits=15, decimal_places=2)
