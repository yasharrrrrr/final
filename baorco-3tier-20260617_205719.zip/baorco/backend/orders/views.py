from rest_framework import viewsets, status, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.db.models import Sum, Count
from orders.models import Cart, CartItem, Order, OrderItem, Payment, InstallmentPlan, ShipmentTracking
from orders.serializers import (
    CartSerializer, CartItemSerializer, OrderListSerializer, OrderDetailSerializer,
    OrderCreateSerializer, PaymentSerializer, InstallmentPlanSerializer,
    ShipmentTrackingSerializer, OrderStatusUpdateSerializer, OrderSearchSerializer,
    OrderStatisticsSerializer
)
from products.models import Product, Discount
from notifications.services import sms_service, email_service
from accounting.tasks import create_invoice, create_journal_entries
import logging

logger = logging.getLogger('baorco')

class CartViewSet(viewsets.ViewSet):
    """
    ViewSet for shopping cart management
    """
    permission_classes = [permissions.IsAuthenticated]
    
    def get_cart(self, user):
        cart, _ = Cart.objects.get_or_create(customer=user)
        return cart
    
    @action(detail=False, methods=['get'])
    def list(self, request):
        """Get user's cart"""
        cart = self.get_cart(request.user)
        serializer = CartSerializer(cart)
        return Response(serializer.data)
    
    @action(detail=False, methods=['post'])
    def add_item(self, request):
        """Add item to cart"""
        product_id = request.data.get('product_id')
        quantity = int(request.data.get('quantity', 1))
        
        if not product_id:
            return Response(
                {'error': 'شناسه محصول الزامی است'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            product = Product.objects.get(id=product_id, status='active')
        except Product.DoesNotExist:
            return Response(
                {'error': 'محصول یافت نشد'},
                status=status.HTTP_404_NOT_FOUND
            )
        
        if quantity > product.quantity:
            return Response(
                {'error': f'موجودی محصول کافی نیست. موجودی: {product.quantity}'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        cart = self.get_cart(request.user)
        price = product.discounted_price if product.discounted_price else product.base_price
        
        cart_item, created = CartItem.objects.get_or_create(
            cart=cart,
            product=product,
            defaults={'quantity': quantity, 'price': price}
        )
        
        if not created:
            cart_item.quantity += quantity
            cart_item.save()
        
        serializer = CartSerializer(cart)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    
    @action(detail=False, methods=['post'])
    def update_item(self, request):
        """Update cart item quantity"""
        cart_item_id = request.data.get('cart_item_id')
        quantity = int(request.data.get('quantity', 1))
        
        try:
            cart_item = CartItem.objects.get(id=cart_item_id, cart__customer=request.user)
            
            if quantity <= 0:
                cart_item.delete()
                return Response({'message': 'آیتم از سبد حذف شد'})
            
            if quantity > cart_item.product.quantity:
                return Response(
                    {'error': 'موجودی کافی نیست'},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            cart_item.quantity = quantity
            cart_item.save()
            
            serializer = CartSerializer(cart_item.cart)
            return Response(serializer.data)
        except CartItem.DoesNotExist:
            return Response(
                {'error': 'آیتم یافت نشد'},
                status=status.HTTP_404_NOT_FOUND
            )
    
    @action(detail=False, methods=['post'])
    def remove_item(self, request):
        """Remove item from cart"""
        cart_item_id = request.data.get('cart_item_id')
        
        try:
            cart_item = CartItem.objects.get(id=cart_item_id, cart__customer=request.user)
            cart = cart_item.cart
            cart_item.delete()
            
            serializer = CartSerializer(cart)
            return Response(serializer.data)
        except CartItem.DoesNotExist:
            return Response(
                {'error': 'آیتم یافت نشد'},
                status=status.HTTP_404_NOT_FOUND
            )
    
    @action(detail=False, methods=['post'])
    def clear(self, request):
        """Clear entire cart"""
        cart = self.get_cart(request.user)
        cart.items.all().delete()
        
        return Response({'message': 'سبد خریدی خالی شد'})


class OrderViewSet(viewsets.ModelViewSet):
    """
    ViewSet for order management
    """
    filter_backends = []
    permission_classes = [permissions.IsAuthenticated]
    
    def get_serializer_class(self):
        if self.action == 'create':
            return OrderCreateSerializer
        elif self.action == 'retrieve':
            return OrderDetailSerializer
        elif self.action == 'update':
            return OrderStatusUpdateSerializer
        return OrderListSerializer
    
    def get_queryset(self):
        if self.request.user.is_admin:
            return Order.objects.all()
        return Order.objects.filter(customer=self.request.user)
    
    def check_admin_permission(self, request):
        if not request.user.is_admin or not request.user.admin_profile.can_manage_orders:
            raise permissions.PermissionDenied('شما اجازه دسترسی ندارید')
    
    def create(self, request, *args, **kwargs):
        """Create new order from cart"""
        cart = get_object_or_404(Cart, customer=request.user)
        
        if not cart.items.exists():
            return Response(
                {'error': 'سبد خریدی خالی است'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Calculate totals
        subtotal = cart.total_price
        discount_amount = 0
        
        discount_code = request.data.get('discount_code')
        discount = None
        if discount_code:
            try:
                discount = Discount.objects.get(code=discount_code, is_active=True)
                if discount.discount_type == 'percentage':
                    discount_amount = (subtotal * discount.discount_value) / 100
                else:
                    discount_amount = discount.discount_value
                discount.current_usage += 1
                discount.save()
            except Discount.DoesNotExist:
                return Response(
                    {'error': 'کد تخفیف نامعتبر است'},
                    status=status.HTTP_400_BAD_REQUEST
                )
        
        # Create order
        is_installment = request.data.get('is_installment', False)
        installment_months = request.data.get('installment_months', 0) if is_installment else 0
        
        tax = (subtotal - discount_amount) * 0.09  # 9% tax
        shipping_cost = 0  # Can be calculated based on address
        total = subtotal - discount_amount + tax + shipping_cost
        
        monthly_payment = (total / installment_months) if installment_months > 0 else 0
        
        order = Order.objects.create(
            customer=request.user,
            shipping_address=request.data.get('shipping_address'),
            shipping_city=request.data.get('shipping_city'),
            shipping_postal_code=request.data.get('shipping_postal_code'),
            shipping_phone=request.data.get('shipping_phone'),
            payment_method=request.data.get('payment_method', 'card'),
            subtotal=subtotal,
            tax=tax,
            shipping_cost=shipping_cost,
            discount_amount=discount_amount,
            discount_code=discount,
            total=total,
            is_installment=is_installment,
            installment_months=installment_months,
            monthly_payment=monthly_payment,
            notes=request.data.get('notes')
        )
        
        # Create order items
        for cart_item in cart.items.all():
            OrderItem.objects.create(
                order=order,
                product=cart_item.product,
                quantity=cart_item.quantity,
                price=cart_item.price
            )
            # Update product sales count
            cart_item.product.sales_count += cart_item.quantity
            cart_item.product.quantity -= cart_item.quantity
            cart_item.product.save()
        
        # Create installment plans if applicable
        if is_installment and installment_months > 0:
            payment_date = timezone.now()
            for i in range(1, installment_months + 1):
                due_date = payment_date + timezone.timedelta(days=30 * i)
                InstallmentPlan.objects.create(
                    order=order,
                    payment_number=i,
                    amount=monthly_payment,
                    due_date=due_date.date()
                )
        
        # Create invoice
        create_invoice.delay(order.id)
        
        # Create journal entries for accounting
        create_journal_entries.delay(order.id)
        
        # Send confirmation notifications
        sms_service.send_order_confirmation(order)
        email_service.send_order_confirmation_email(order)
        
        # Clear cart
        cart.items.all().delete()
        
        return Response(
            OrderDetailSerializer(order).data,
            status=status.HTTP_201_CREATED
        )
    
    def update(self, request, *args, **kwargs):
        """Update order status (admin only)"""
        self.check_admin_permission(request)
        
        order = self.get_object()
        serializer = OrderStatusUpdateSerializer(order, data=request.data, partial=True)
        
        if serializer.is_valid():
            serializer.save()
            return Response(OrderDetailSerializer(order).data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=True, methods=['post'])
    def confirm(self, request, pk=None):
        """Confirm order (admin only)"""
        self.check_admin_permission(request)
        
        order = self.get_object()
        order.status = 'confirmed'
        order.save()
        
        return Response({'message': 'سفارش تایید شد'})
    
    @action(detail=True, methods=['post'])
    def ship(self, request, pk=None):
        """Mark order as shipped (admin only)"""
        self.check_admin_permission(request)
        
        order = self.get_object()
        tracking_number = request.data.get('tracking_number')
        
        if not tracking_number:
            return Response(
                {'error': 'شماره پیگیری الزامی است'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        order.status = 'shipped'
        order.tracking_number = tracking_number
        order.shipped_at = timezone.now()
        order.save()
        
        ShipmentTracking.objects.create(
            order=order,
            status='shipped',
            description='سفارش ارسال شده است'
        )
        
        # Send shipment notification
        sms_service.send_shipment_notification(order, tracking_number, 'shipped')
        
        return Response(OrderDetailSerializer(order).data)
    
    @action(detail=True, methods=['post'])
    def deliver(self, request, pk=None):
        """Mark order as delivered (admin only)"""
        self.check_admin_permission(request)
        
        order = self.get_object()
        order.status = 'delivered'
        order.delivered_at = timezone.now()
        order.save()
        
        ShipmentTracking.objects.create(
            order=order,
            status='delivered',
            description='سفارش تحویل داده شد'
        )
        
        return Response(OrderDetailSerializer(order).data)
    
    @action(detail=True, methods=['post'])
    def cancel(self, request, pk=None):
        """Cancel order"""
        order = self.get_object()
        
        # Only allow cancellation if not already shipped
        if order.status in ['shipped', 'delivered']:
            return Response(
                {'error': 'سفارش ارسال شده یا تحویل داده شده را نمی‌توان لغو کرد'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        order.status = 'cancelled'
        order.save()
        
        # Restore product quantities
        for item in order.items.all():
            item.product.quantity += item.quantity
            item.product.sales_count -= item.quantity
            item.product.save()
        
        return Response({'message': 'سفارش لغو شد'})
    
    @action(detail=False, methods=['get'])
    def search(self, request):
        """Search orders"""
        self.check_admin_permission(request)
        
        serializer = OrderSearchSerializer(data=request.query_params)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        queryset = self.get_queryset()
        
        order_number = serializer.validated_data.get('order_number')
        if order_number:
            queryset = queryset.filter(order_number__icontains=order_number)
        
        status_filter = serializer.validated_data.get('status')
        if status_filter:
            queryset = queryset.filter(status=status_filter)
        
        payment_status = serializer.validated_data.get('payment_status')
        if payment_status:
            queryset = queryset.filter(payment_status=payment_status)
        
        date_from = serializer.validated_data.get('date_from')
        if date_from:
            queryset = queryset.filter(created_at__gte=date_from)
        
        date_to = serializer.validated_data.get('date_to')
        if date_to:
            queryset = queryset.filter(created_at__lte=date_to)
        
        serializer = OrderListSerializer(queryset, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def statistics(self, request):
        """Get order statistics (admin only)"""
        self.check_admin_permission(request)
        
        total_orders = Order.objects.count()
        pending_orders = Order.objects.filter(status='pending').count()
        completed_orders = Order.objects.filter(status='delivered').count()
        cancelled_orders = Order.objects.filter(status='cancelled').count()
        
        stats = Order.objects.aggregate(
            total_revenue=Sum('total'),
        )
        
        avg_order_value = stats['total_revenue'] / total_orders if total_orders > 0 else 0
        
        data = {
            'total_orders': total_orders,
            'pending_orders': pending_orders,
            'completed_orders': completed_orders,
            'cancelled_orders': cancelled_orders,
            'total_revenue': stats['total_revenue'] or 0,
            'average_order_value': avg_order_value
        }
        
        serializer = OrderStatisticsSerializer(data)
        return Response(serializer.data)


class PaymentViewSet(viewsets.ModelViewSet):
    """
    ViewSet for payment management
    """
    serializer_class = PaymentSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        if self.request.user.is_admin:
            return Payment.objects.all()
        return Payment.objects.filter(order__customer=self.request.user)


class ShipmentTrackingViewSet(viewsets.ReadOnlyModelViewSet):
    """
    ViewSet for shipment tracking
    """
    serializer_class = ShipmentTrackingSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        if self.request.user.is_admin:
            return ShipmentTracking.objects.all()
        return ShipmentTracking.objects.filter(order__customer=self.request.user)
