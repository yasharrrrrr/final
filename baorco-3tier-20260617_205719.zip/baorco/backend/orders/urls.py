from django.urls import path, include
from rest_framework.routers import DefaultRouter
from orders.views import CartViewSet, OrderViewSet, PaymentViewSet, ShipmentTrackingViewSet

router = DefaultRouter()
router.register(r'cart', CartViewSet, basename='cart')
router.register(r'orders', OrderViewSet, basename='order')
router.register(r'payments', PaymentViewSet, basename='payment')
router.register(r'shipments', ShipmentTrackingViewSet, basename='shipment')

urlpatterns = [
    path('', include(router.urls)),
]
