# __init__.py for orders
default_app_config = 'orders.apps.OrdersConfig'
