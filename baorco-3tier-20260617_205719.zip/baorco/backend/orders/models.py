from django.db import models
from django.core.validators import MinValueValidator
from django.utils import timezone

class Cart(models.Model):
    """
    Shopping cart for customers
    """
    customer = models.OneToOneField('accounts.User', on_delete=models.CASCADE, related_name='cart')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'سبد خریدی'
        verbose_name_plural = 'سبد‌های خریدی'
    
    def __str__(self):
        return f"Cart for {self.customer.username}"
    
    @property
    def total_price(self):
        return sum(item.total_price for item in self.items.all())
    
    @property
    def total_items(self):
        return sum(item.quantity for item in self.items.all())


class CartItem(models.Model):
    """
    Items in shopping cart
    """
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE, related_name='items')
    product = models.ForeignKey('products.Product', on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1, validators=[MinValueValidator(1)])
    price = models.DecimalField(max_digits=15, decimal_places=2)  # Price at time of adding
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'آیتم سبد'
        verbose_name_plural = 'آیتم‌های سبد'
        unique_together = ('cart', 'product')
    
    def __str__(self):
        return f"{self.product.name} x {self.quantity}"
    
    @property
    def total_price(self):
        return self.price * self.quantity


class Order(models.Model):
    """
    Main order model
    """
    ORDER_STATUS_CHOICES = (
        ('pending', 'در انتظار تایید'),
        ('confirmed', 'تایید شده'),
        ('processing', 'در حال پردازش'),
        ('shipped', 'ارسال شده'),
        ('delivered', 'تحویل داده شده'),
        ('cancelled', 'لغو شده'),
        ('refunded', 'مسترجع شده'),
    )
    
    PAYMENT_STATUS_CHOICES = (
        ('pending', 'در انتظار'),
        ('paid', 'پرداخت شده'),
        ('partial', 'پرداخت جزئی'),
        ('failed', 'ناموفق'),
        ('refunded', 'بازگشت داده شده'),
    )
    
    PAYMENT_METHOD_CHOICES = (
        ('card', 'کارت بانکی'),
        ('installment', 'اقساطی'),
        ('bank_transfer', 'انتقال بانکی'),
        ('cash', 'نقد'),
    )
    
    order_number = models.CharField(max_length=50, unique=True)
    customer = models.ForeignKey('accounts.User', on_delete=models.CASCADE, related_name='orders')
    
    # Shipping Information
    shipping_address = models.TextField()
    shipping_city = models.CharField(max_length=100)
    shipping_postal_code = models.CharField(max_length=20)
    shipping_phone = models.CharField(max_length=20)
    
    # Order Details
    status = models.CharField(max_length=20, choices=ORDER_STATUS_CHOICES, default='pending')
    payment_status = models.CharField(max_length=20, choices=PAYMENT_STATUS_CHOICES, default='pending')
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHOD_CHOICES)
    
    # Pricing
    subtotal = models.DecimalField(max_digits=15, decimal_places=2)
    tax = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    shipping_cost = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    discount_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=15, decimal_places=2)
    
    # Discount
    discount_code = models.ForeignKey(
        'products.Discount',
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name='orders'
    )
    
    # Installment
    is_installment = models.BooleanField(default=False)
    installment_months = models.IntegerField(blank=True, null=True)
    monthly_payment = models.DecimalField(max_digits=15, decimal_places=2, blank=True, null=True)
    
    # Notes
    notes = models.TextField(blank=True, null=True)
    admin_notes = models.TextField(blank=True, null=True)
    
    # Tracking
    tracking_number = models.CharField(max_length=100, blank=True, null=True)
    estimated_delivery = models.DateField(blank=True, null=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    shipped_at = models.DateTimeField(blank=True, null=True)
    delivered_at = models.DateTimeField(blank=True, null=True)
    
    class Meta:
        verbose_name = 'سفارش'
        verbose_name_plural = 'سفارشات'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['order_number']),
            models.Index(fields=['customer']),
            models.Index(fields=['status']),
            models.Index(fields=['payment_status']),
        ]
    
    def __str__(self):
        return f"Order {self.order_number}"
    
    def save(self, *args, **kwargs):
        if not self.order_number:
            import uuid
            self.order_number = f"ORD-{timezone.now().strftime('%Y%m%d')}-{uuid.uuid4().hex[:6].upper()}"
        super().save(*args, **kwargs)


class OrderItem(models.Model):
    """
    Items in an order
    """
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='items')
    product = models.ForeignKey('products.Product', on_delete=models.SET_NULL, null=True)
    quantity = models.IntegerField(validators=[MinValueValidator(1)])
    price = models.DecimalField(max_digits=15, decimal_places=2)
    discount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    
    class Meta:
        verbose_name = 'آیتم سفارش'
        verbose_name_plural = 'آیتم‌های سفارش'
    
    def __str__(self):
        return f"{self.product.name} x {self.quantity}"
    
    @property
    def total_price(self):
        return (self.price * self.quantity) - self.discount


class Payment(models.Model):
    """
    Payment tracking for orders
    """
    PAYMENT_STATUS_CHOICES = (
        ('pending', 'در انتظار'),
        ('processing', 'در حال پردازش'),
        ('completed', 'تکمیل شده'),
        ('failed', 'ناموفق'),
        ('refunded', 'بازگشت داده شده'),
    )
    
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='payments')
    amount = models.DecimalField(max_digits=15, decimal_places=2)
    status = models.CharField(max_length=20, choices=PAYMENT_STATUS_CHOICES, default='pending')
    payment_gateway = models.CharField(max_length=50)  # e.g., 'zarinpal', 'idpay'
    transaction_id = models.CharField(max_length=100, unique=True, blank=True, null=True)
    reference_id = models.CharField(max_length=100, blank=True, null=True)
    payment_date = models.DateTimeField(blank=True, null=True)
    error_message = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'پرداخت'
        verbose_name_plural = 'پرداخت‌ها'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"Payment for {self.order.order_number}"


class InstallmentPlan(models.Model):
    """
    Installment payment plan tracking
    """
    PAYMENT_STATUS_CHOICES = (
        ('pending', 'در انتظار'),
        ('paid', 'پرداخت شده'),
        ('overdue', 'سررسید'),
        ('cancelled', 'لغو شده'),
    )
    
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='installment_plans')
    payment_number = models.IntegerField()  # 1st, 2nd payment, etc.
    amount = models.DecimalField(max_digits=15, decimal_places=2)
    due_date = models.DateField()
    status = models.CharField(max_length=20, choices=PAYMENT_STATUS_CHOICES, default='pending')
    paid_date = models.DateField(blank=True, null=True)
    payment_method = models.CharField(max_length=50, blank=True, null=True)
    reference_number = models.CharField(max_length=100, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'اقساط'
        verbose_name_plural = 'اقساطات'
        unique_together = ('order', 'payment_number')
        ordering = ['order', 'payment_number']
    
    def __str__(self):
        return f"Installment {self.payment_number} for {self.order.order_number}"
    
    @property
    def is_overdue(self):
        return self.status == 'pending' and timezone.now().date() > self.due_date


class ShipmentTracking(models.Model):
    """
    Track shipment status and location
    """
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='shipment_tracking')
    status = models.CharField(max_length=50)
    location = models.CharField(max_length=255, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'ردیابی ارسالات'
        verbose_name_plural = 'ردیابی ارسالات'
        ordering = ['-updated_at']
    
    def __str__(self):
        return f"{self.order.order_number} - {self.status}"
