from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from accounts.models import User, AdminProfile, CustomerProfile, LoginLog

@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = ('username', 'email', 'phone', 'role', 'is_verified', 'is_active', 'created_at')
    list_filter = ('role', 'is_verified', 'is_active', 'created_at')
    search_fields = ('username', 'email', 'phone', 'national_id')
    readonly_fields = ('created_at', 'updated_at')
    
    fieldsets = BaseUserAdmin.fieldsets + (
        ('Custom Fields', {
            'fields': ('phone', 'national_id', 'address', 'city', 'postal_code', 
                      'role', 'is_verified', 'verification_code', 'profile_image')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

@admin.register(AdminProfile)
class AdminProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'department', 'can_manage_products', 'can_manage_orders', 'created_at')
    list_filter = ('can_manage_products', 'can_manage_orders', 'can_manage_accounting', 'created_at')
    search_fields = ('user__username', 'department')
    readonly_fields = ('created_at', 'updated_at')

@admin.register(CustomerProfile)
class CustomerProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'loyalty_points', 'total_purchases', 'preferred_payment_method', 'created_at')
    list_filter = ('preferred_payment_method', 'created_at')
    search_fields = ('user__username', 'company_name', 'tax_id')
    readonly_fields = ('loyalty_points', 'total_purchases', 'created_at', 'updated_at')

@admin.register(LoginLog)
class LoginLogAdmin(admin.ModelAdmin):
    list_display = ('user', 'ip_address', 'login_time', 'is_successful')
    list_filter = ('is_successful', 'login_time')
    search_fields = ('user__username', 'ip_address')
    readonly_fields = ('user', 'ip_address', 'user_agent', 'login_time', 'logout_time', 'device_info')
    
    def has_add_permission(self, request):
        return False
    
    def has_change_permission(self, request, obj=None):
        return False
