"""
Fixes a real, easy-to-miss bug: Django (and mssql-django) only create
TABLES via migrate -- they never create the DATABASE itself. On a brand
new MSSQL container, the only database that exists is "master". Without
this step, `manage.py migrate` fails with:
    Login failed for user 'sa'. Cannot open database "BAORCO_Shop"
    requested by the login.

This command connects to "master" directly via pyodbc (bypassing the
Django ORM, since the target database doesn't exist yet) and creates
the configured database if it's missing. Safe no-op on SQLite.
"""
from django.conf import settings
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Creates the configured MSSQL database if it doesn't exist yet (no-op on SQLite)"

    def handle(self, *args, **options):
        db = settings.DATABASES["default"]

        if "mssql" not in db["ENGINE"]:
            self.stdout.write("Not using MSSQL -- nothing to do.")
            return

        try:
            import pyodbc
        except ImportError:
            self.stderr.write(self.style.ERROR(
                "pyodbc is not installed. Run: pip install pyodbc"
            ))
            raise

        driver = db["OPTIONS"].get("driver", "ODBC Driver 18 for SQL Server")
        extra_params = db["OPTIONS"].get("extra_params", "")
        db_name = db["NAME"]

        conn_str = (
            f"DRIVER={{{driver}}};"
            f"SERVER={db['HOST']},{db['PORT']};"
            f"DATABASE=master;"
            f"UID={db['USER']};"
            f"PWD={db['PASSWORD']};"
            f"{extra_params}"
        )

        self.stdout.write(f"Connecting to master on {db['HOST']}:{db['PORT']} to check for '{db_name}'...")

        try:
            conn = pyodbc.connect(conn_str, autocommit=True, timeout=15)
            cursor = conn.cursor()
            cursor.execute(
                "IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = ?) "
                "EXEC('CREATE DATABASE [" + db_name.replace("]", "]]") + "]')",
                db_name,
            )
            cursor.close()
            conn.close()
            self.stdout.write(self.style.SUCCESS(f"Database '{db_name}' is ready."))
        except Exception as exc:
            self.stderr.write(self.style.ERROR(f"Could not ensure database exists: {exc}"))
            raise
