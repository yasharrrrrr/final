from django.db import models
from django.contrib.auth.models import AbstractUser
from django.core.validators import RegexValidator

class User(AbstractUser):
    """
    Custom user model with extended fields for admin and customer roles
    """
    ROLE_CHOICES = (
        ('admin', 'مدیر'),
        ('customer', 'مشتری'),
        ('support', 'پشتیبانی'),
    )
    
    phone_regex = RegexValidator(
        regex=r'^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$',
        message='شماره تلفن معتبر نیست'
    )
    
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='customer')
    phone = models.CharField(validators=[phone_regex], max_length=17, blank=True, null=True)
    national_id = models.CharField(max_length=10, unique=True, blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    city = models.CharField(max_length=100, blank=True, null=True)
    postal_code = models.CharField(max_length=20, blank=True, null=True)
    is_verified = models.BooleanField(default=False)
    verification_code = models.CharField(max_length=6, blank=True, null=True)
    verification_code_expires = models.DateTimeField(blank=True, null=True)
    profile_image = models.ImageField(upload_to='profiles/', blank=True, null=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
        verbose_name = 'کاربر'
        verbose_name_plural = 'کاربران'
        indexes = [
            models.Index(fields=['phone']),
            models.Index(fields=['national_id']),
            models.Index(fields=['role']),
        ]
    
    def __str__(self):
        return f"{self.username} ({self.get_role_display()})"
    
    @property
    def is_admin(self):
        return self.role == 'admin' or self.is_staff
    
    @property
    def is_customer(self):
        return self.role == 'customer'


class AdminProfile(models.Model):
    """
    Extended admin profile with permissions
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='admin_profile')
    can_manage_products = models.BooleanField(default=True)
    can_manage_orders = models.BooleanField(default=True)
    can_manage_accounting = models.BooleanField(default=True)
    can_manage_users = models.BooleanField(default=True)
    can_manage_reports = models.BooleanField(default=True)
    can_view_analytics = models.BooleanField(default=True)
    department = models.CharField(max_length=100, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'پروفایل مدیر'
        verbose_name_plural = 'پروفایل‌های مدیر'
    
    def __str__(self):
        return f"Admin Profile: {self.user.username}"


class CustomerProfile(models.Model):
    """
    Extended customer profile with preferences and loyalty
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='customer_profile')
    loyalty_points = models.IntegerField(default=0)
    total_purchases = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    preferred_payment_method = models.CharField(
        max_length=50,
        choices=[('card', 'کارت بانکی'), ('installment', 'اقساطی')],
        default='card'
    )
    company_name = models.CharField(max_length=255, blank=True, null=True)
    business_type = models.CharField(max_length=255, blank=True, null=True)
    tax_id = models.CharField(max_length=50, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'پروفایل مشتری'
        verbose_name_plural = 'پروفایل‌های مشتری'
    
    def __str__(self):
        return f"Customer Profile: {self.user.username}"


class LoginLog(models.Model):
    """
    Track user login history for security
    """
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='login_logs')
    ip_address = models.GenericIPAddressField()
    user_agent = models.TextField()
    login_time = models.DateTimeField(auto_now_add=True)
    logout_time = models.DateTimeField(blank=True, null=True)
    is_successful = models.BooleanField(default=True)
    device_info = models.JSONField(null=True, blank=True)
    
    class Meta:
        ordering = ['-login_time']
        verbose_name = 'لاگ ورود'
        verbose_name_plural = 'لاگ‌های ورود'
    
    def __str__(self):
        return f"{self.user.username} - {self.login_time}"
