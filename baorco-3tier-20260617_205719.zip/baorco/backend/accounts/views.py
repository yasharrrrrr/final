from rest_framework import viewsets, status, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.auth import authenticate, get_user_model
from django.utils import timezone
from accounts.models import AdminProfile, CustomerProfile, LoginLog
from accounts.serializers import (
    UserSerializer, AdminProfileSerializer, CustomerProfileSerializer,
    RegisterSerializer, LoginSerializer, TokenSerializer, ChangePasswordSerializer,
    PhoneVerificationSerializer, OTPVerificationSerializer, LoginLogSerializer,
    UserDetailSerializer, AdminListSerializer, CustomerListSerializer
)
from notifications.services import sms_service, email_service
from rest_framework_simplejwt.tokens import RefreshToken
import logging

logger = logging.getLogger('baorco')
User = get_user_model()

class RegisterView(APIView):
    """
    User registration endpoint
    """
    permission_classes = [permissions.AllowAny]
    
    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            user.role = 'customer'
            user.save()
            
            # Create customer profile
            CustomerProfile.objects.create(user=user)
            
            # Send welcome email
            email_service.send_welcome_email(user)
            
            return Response(
                {'message': 'کاربر با موفقیت ثبت نام کرد', 'user': UserSerializer(user).data},
                status=status.HTTP_201_CREATED
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class LoginView(APIView):
    """
    User login endpoint
    """
    permission_classes = [permissions.AllowAny]
    
    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.validated_data['user']
            
            # Check if user is active
            if not user.is_active:
                return Response(
                    {'error': 'حساب کاربری شما غیرفعال است'},
                    status=status.HTTP_401_UNAUTHORIZED
                )
            
            # Create tokens
            refresh = RefreshToken.for_user(user)
            
            # Log login
            ip_address = self._get_client_ip(request)
            LoginLog.objects.create(
                user=user,
                ip_address=ip_address,
                user_agent=request.META.get('HTTP_USER_AGENT', ''),
                is_successful=True
            )
            
            return Response({
                'refresh': str(refresh),
                'access': str(refresh.access_token),
                'user': UserDetailSerializer(user).data
            })
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    @staticmethod
    def _get_client_ip(request):
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            ip = x_forwarded_for.split(',')[0]
        else:
            ip = request.META.get('REMOTE_ADDR')
        return ip


class PhoneVerificationView(APIView):
    """
    Send OTP to phone number for verification
    """
    permission_classes = [permissions.AllowAny]
    
    def post(self, request):
        serializer = PhoneVerificationSerializer(data=request.data)
        if serializer.is_valid():
            phone = serializer.validated_data['phone']
            
            # Check if phone already exists
            try:
                user = User.objects.get(phone=phone, is_verified=True)
                return Response(
                    {'error': 'این شماره تلفن قبلا ثبت شده است'},
                    status=status.HTTP_400_BAD_REQUEST
                )
            except User.DoesNotExist:
                pass
            
            # Send OTP
            otp_code, sms_log = sms_service.send_otp(phone)
            
            if otp_code:
                return Response({
                    'message': 'کد تأیید برای شماره تلفن ارسال شد',
                    'phone': phone
                })
            else:
                return Response(
                    {'error': 'خطا در ارسال کد تأیید'},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class OTPVerificationView(APIView):
    """
    Verify OTP code and authenticate user
    """
    permission_classes = [permissions.AllowAny]
    
    def post(self, request):
        serializer = OTPVerificationSerializer(data=request.data)
        if serializer.is_valid():
            phone = serializer.validated_data['phone']
            code = serializer.validated_data['code']
            
            from notifications.models import OTPCode
            
            try:
                otp = OTPCode.objects.get(phone=phone, code=code, status='active')
                
                if not otp.is_valid:
                    return Response(
                        {'error': 'کد تأیید منقضی شده است یا تعداد تلاش‌های زیادی انجام شده است'},
                        status=status.HTTP_400_BAD_REQUEST
                    )
                
                # Mark OTP as verified
                otp.status = 'verified'
                otp.verified_at = timezone.now()
                otp.save()
                
                # Get or create user
                user = otp.user
                user.is_verified = True
                user.save()
                
                # Create tokens
                refresh = RefreshToken.for_user(user)
                
                return Response({
                    'refresh': str(refresh),
                    'access': str(refresh.access_token),
                    'user': UserDetailSerializer(user).data
                })
                
            except OTPCode.DoesNotExist:
                return Response(
                    {'error': 'کد تأیید نامعتبر است'},
                    status=status.HTTP_400_BAD_REQUEST
                )
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UserViewSet(viewsets.ModelViewSet):
    """
    ViewSet for user management
    """
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_serializer_class(self):
        if self.action == 'retrieve' or self.action == 'update':
            return UserDetailSerializer
        return super().get_serializer_class()
    
    def get_queryset(self):
        if self.request.user.is_admin:
            return User.objects.all()
        return User.objects.filter(id=self.request.user.id)
    
    @action(detail=False, methods=['get'])
    def me(self, request):
        serializer = UserDetailSerializer(request.user)
        return Response(serializer.data)
    
    @action(detail=False, methods=['post'])
    def change_password(self, request):
        serializer = ChangePasswordSerializer(data=request.data)
        if serializer.is_valid():
            user = request.user
            if not user.check_password(serializer.validated_data['old_password']):
                return Response(
                    {'error': 'رمز عبور فعلی نامعتبر است'},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            user.set_password(serializer.validated_data['new_password'])
            user.save()
            
            return Response({'message': 'رمز عبور تغییر یافت'})
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=False, methods=['get'])
    def login_logs(self, request):
        logs = LoginLog.objects.filter(user=request.user)[:20]
        serializer = LoginLogSerializer(logs, many=True)
        return Response(serializer.data)


class AdminViewSet(viewsets.ModelViewSet):
    """
    ViewSet for admin management
    """
    queryset = User.objects.all()  # Will be filtered in get_queryset()
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        """Override to filter admins"""
        return User.objects.filter(role='admin')
    
    def get_serializer_class(self):
        if self.action == 'list':
            return AdminListSerializer
        return UserDetailSerializer
    
    def check_permissions(self, request):
        if not request.user.is_admin or not request.user.admin_profile.can_manage_users:
            raise permissions.PermissionDenied('شما اجازه دسترسی ندارید')
        super().check_permissions(request)
    
    def create(self, request, *args, **kwargs):
        """Create new admin user"""
        serializer = UserDetailSerializer(data=request.data)
        if serializer.is_valid():
            user = User.objects.create_user(
                username=serializer.validated_data['username'],
                email=serializer.validated_data.get('email'),
                password=request.data.get('password')
            )
            user.role = 'admin'
            user.is_staff = True
            user.save()
            
            AdminProfile.objects.create(user=user)
            
            return Response(
                UserDetailSerializer(user).data,
                status=status.HTTP_201_CREATED
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class CustomerViewSet(viewsets.ReadOnlyModelViewSet):
    """
    ViewSet for customer management (read-only for admins)
    """
    queryset = User.objects.all()  # Will be filtered in get_queryset()
    serializer_class = CustomerListSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        """Override to filter customers"""
        return User.objects.filter(role='customer')
    
    def check_permissions(self, request):
        if not request.user.is_admin or not request.user.admin_profile.can_manage_users:
            raise permissions.PermissionDenied('شما اجازه دسترسی ندارید')
        super().check_permissions(request)


class AdminProfileViewSet(viewsets.ModelViewSet):
    """
    ViewSet for admin profile management
    """
    queryset = AdminProfile.objects.all()
    serializer_class = AdminProfileSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        if self.request.user.is_admin:
            return AdminProfile.objects.all()
        return AdminProfile.objects.filter(user=self.request.user)
    
    def check_permissions(self, request):
        if not request.user.is_admin:
            raise permissions.PermissionDenied('شما اجازه دسترسی ندارید')
        super().check_permissions(request)


class CustomerProfileViewSet(viewsets.ModelViewSet):
    """
    ViewSet for customer profile management
    """
    queryset = CustomerProfile.objects.all()
    serializer_class = CustomerProfileSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        if self.request.user.is_admin:
            return CustomerProfile.objects.all()
        return CustomerProfile.objects.filter(user=self.request.user)
    
    @action(detail=False, methods=['get', 'put'])
    def my_profile(self, request):
        try:
            profile = request.user.customer_profile
            if request.method == 'GET':
                serializer = CustomerProfileSerializer(profile)
                return Response(serializer.data)
            else:
                serializer = CustomerProfileSerializer(profile, data=request.data, partial=True)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except CustomerProfile.DoesNotExist:
            return Response(
                {'error': 'پروفایل پیدا نشد'},
                status=status.HTTP_404_NOT_FOUND
            )
