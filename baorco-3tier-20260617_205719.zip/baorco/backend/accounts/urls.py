from django.urls import path, include
from rest_framework.routers import DefaultRouter
from accounts.views import (
    RegisterView, LoginView, PhoneVerificationView, OTPVerificationView,
    UserViewSet, AdminViewSet, CustomerViewSet, 
    AdminProfileViewSet, CustomerProfileViewSet
)

router = DefaultRouter()
router.register(r'users', UserViewSet, basename='user')
router.register(r'admins', AdminViewSet, basename='admin')
router.register(r'customers', CustomerViewSet, basename='customer')
router.register(r'admin-profiles', AdminProfileViewSet, basename='admin-profile')
router.register(r'customer-profiles', CustomerProfileViewSet, basename='customer-profile')

urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('login/', LoginView.as_view(), name='login'),
    path('phone-verification/', PhoneVerificationView.as_view(), name='phone-verification'),
    path('otp-verification/', OTPVerificationView.as_view(), name='otp-verification'),
    path('', include(router.urls)),
]
