from rest_framework import serializers
from django.contrib.auth import get_user_model
from rest_framework_simplejwt.tokens import RefreshToken
from accounts.models import AdminProfile, CustomerProfile, LoginLog

User = get_user_model()

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name', 'phone', 
                  'national_id', 'address', 'city', 'postal_code', 'is_verified', 
                  'profile_image', 'role', 'is_active', 'created_at']
        read_only_fields = ['id', 'is_verified', 'created_at']


class AdminProfileSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    
    class Meta:
        model = AdminProfile
        fields = ['id', 'user', 'can_manage_products', 'can_manage_orders', 
                  'can_manage_accounting', 'can_manage_users', 'can_manage_reports', 
                  'can_view_analytics', 'department', 'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']


class CustomerProfileSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    
    class Meta:
        model = CustomerProfile
        fields = ['id', 'user', 'loyalty_points', 'total_purchases', 
                  'preferred_payment_method', 'company_name', 'business_type', 
                  'tax_id', 'created_at', 'updated_at']
        read_only_fields = ['id', 'loyalty_points', 'total_purchases', 'created_at', 'updated_at']


class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, style={'input_type': 'password'})
    password2 = serializers.CharField(write_only=True, style={'input_type': 'password'})
    
    class Meta:
        model = User
        fields = ['username', 'email', 'phone', 'password', 'password2']
    
    def validate(self, data):
        if data['password'] != data['password2']:
            raise serializers.ValidationError({"password": "رمز عبور تطابق ندارد"})
        if len(data['password']) < 8:
            raise serializers.ValidationError({"password": "رمز عبور باید حداقل 8 کاراکتر باشد"})
        return data
    
    def create(self, validated_data):
        validated_data.pop('password2')
        password = validated_data.pop('password')
        user = User.objects.create_user(**validated_data)
        user.set_password(password)
        user.save()
        return user


class LoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField(write_only=True)
    
    def validate(self, data):
        from django.contrib.auth import authenticate
        user = authenticate(**data)
        if not user:
            raise serializers.ValidationError("نام کاربری یا رمز عبور اشتباه است")
        data['user'] = user
        return data


class TokenSerializer(serializers.Serializer):
    refresh = serializers.CharField(read_only=True)
    access = serializers.CharField(read_only=True)
    
    def create(self, validated_data):
        user = validated_data['user']
        refresh = RefreshToken.for_user(user)
        return {
            'refresh': str(refresh),
            'access': str(refresh.access_token),
        }


class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(write_only=True)
    new_password = serializers.CharField(write_only=True)
    new_password2 = serializers.CharField(write_only=True)
    
    def validate(self, data):
        if data['new_password'] != data['new_password2']:
            raise serializers.ValidationError({"new_password": "رمزهای جدید تطابق ندارند"})
        if len(data['new_password']) < 8:
            raise serializers.ValidationError({"new_password": "رمز عبور باید حداقل 8 کاراکتر باشد"})
        return data


class PhoneVerificationSerializer(serializers.Serializer):
    phone = serializers.CharField(max_length=20)


class OTPVerificationSerializer(serializers.Serializer):
    phone = serializers.CharField(max_length=20)
    code = serializers.CharField(max_length=6)


class LoginLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = LoginLog
        fields = ['id', 'ip_address', 'login_time', 'logout_time', 'is_successful', 'device_info']
        read_only_fields = ['id', 'login_time']


class UserDetailSerializer(serializers.ModelSerializer):
    admin_profile = AdminProfileSerializer(read_only=True)
    customer_profile = CustomerProfileSerializer(read_only=True)
    
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name', 'phone', 
                  'national_id', 'address', 'city', 'postal_code', 'is_verified', 
                  'profile_image', 'role', 'is_active', 'admin_profile', 'customer_profile', 
                  'created_at', 'updated_at']
        read_only_fields = ['id', 'is_verified', 'created_at', 'updated_at']


class AdminListSerializer(serializers.ModelSerializer):
    admin_profile = AdminProfileSerializer(read_only=True)
    
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name', 'phone', 
                  'is_active', 'admin_profile', 'created_at']
        read_only_fields = ['id', 'created_at']


class CustomerListSerializer(serializers.ModelSerializer):
    customer_profile = CustomerProfileSerializer(read_only=True)
    
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name', 'phone', 
                  'national_id', 'address', 'city', 'is_verified', 'customer_profile', 
                  'created_at']
        read_only_fields = ['id', 'created_at']
