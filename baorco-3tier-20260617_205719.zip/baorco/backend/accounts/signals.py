from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth import get_user_model
from accounts.models import AdminProfile, CustomerProfile

User = get_user_model()

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    """
    Create appropriate profile when user is created
    """
    if created:
        if instance.role == 'admin':
            AdminProfile.objects.get_or_create(user=instance)
        elif instance.role == 'customer':
            CustomerProfile.objects.get_or_create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    """
    Save profile when user is saved
    """
    if instance.role == 'admin' and hasattr(instance, 'admin_profile'):
        instance.admin_profile.save()
    elif instance.role == 'customer' and hasattr(instance, 'customer_profile'):
        instance.customer_profile.save()
