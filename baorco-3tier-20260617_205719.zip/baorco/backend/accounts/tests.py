from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient, APITestCase
from rest_framework import status
from accounts.models import AdminProfile, CustomerProfile
from core.utils import PhoneValidator, NationalIDValidator, EmailValidator

User = get_user_model()

class PhoneValidatorTests(TestCase):
    """Test phone validation"""
    
    def test_valid_phone_with_98(self):
        self.assertTrue(PhoneValidator.validate('989123456789'))
    
    def test_valid_phone_with_0(self):
        self.assertTrue(PhoneValidator.validate('09123456789'))
    
    def test_valid_phone_with_plus(self):
        self.assertTrue(PhoneValidator.validate('+989123456789'))
    
    def test_invalid_phone_short(self):
        self.assertFalse(PhoneValidator.validate('9123456'))
    
    def test_phone_normalization(self):
        normalized = PhoneValidator.normalize('09123456789')
        self.assertEqual(normalized, '989123456789')

class NationalIDValidatorTests(TestCase):
    """Test national ID validation"""
    
    def test_valid_national_id(self):
        # Example valid ID
        self.assertTrue(NationalIDValidator.validate('0012345670'))
    
    def test_invalid_national_id_short(self):
        self.assertFalse(NationalIDValidator.validate('123456'))
    
    def test_invalid_national_id_non_digit(self):
        self.assertFalse(NationalIDValidator.validate('001234567A'))

class EmailValidatorTests(TestCase):
    """Test email validation"""
    
    def test_valid_email(self):
        self.assertTrue(EmailValidator.validate('test@example.com'))
    
    def test_invalid_email_no_domain(self):
        self.assertFalse(EmailValidator.validate('test@'))
    
    def test_invalid_email_no_at(self):
        self.assertFalse(EmailValidator.validate('testexample.com'))

class UserRegistrationAPITests(APITestCase):
    """Test user registration API"""
    
    def setUp(self):
        self.client = APIClient()
    
    def test_user_registration(self):
        data = {
            'username': 'testuser',
            'email': 'test@example.com',
            'phone': '989123456789',
            'password': 'TestPassword123',
            'password2': 'TestPassword123'
        }
        response = self.client.post('/api/auth/register/', data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(User.objects.count(), 1)
    
    def test_duplicate_username(self):
        User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='TestPassword123'
        )
        data = {
            'username': 'testuser',
            'email': 'test2@example.com',
            'phone': '989123456789',
            'password': 'TestPassword123',
            'password2': 'TestPassword123'
        }
        response = self.client.post('/api/auth/register/', data, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
    
    def test_password_mismatch(self):
        data = {
            'username': 'testuser',
            'email': 'test@example.com',
            'phone': '989123456789',
            'password': 'TestPassword123',
            'password2': 'DifferentPassword123'
        }
        response = self.client.post('/api/auth/register/', data, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

class UserLoginAPITests(APITestCase):
    """Test user login API"""
    
    def setUp(self):
        self.client = APIClient()
        self.user = User.objects.create_user(
            username='testuser',
            password='TestPassword123'
        )
    
    def test_successful_login(self):
        data = {
            'username': 'testuser',
            'password': 'TestPassword123'
        }
        response = self.client.post('/api/auth/login/', data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('access', response.data)
        self.assertIn('refresh', response.data)
    
    def test_invalid_credentials(self):
        data = {
            'username': 'testuser',
            'password': 'WrongPassword'
        }
        response = self.client.post('/api/auth/login/', data, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

class AdminProfileTests(TestCase):
    """Test admin profile creation"""
    
    def setUp(self):
        self.admin_user = User.objects.create_user(
            username='admin',
            email='admin@example.com',
            password='AdminPassword123',
            role='admin'
        )
    
    def test_admin_profile_created(self):
        self.assertTrue(
            AdminProfile.objects.filter(user=self.admin_user).exists()
        )
    
    def test_admin_permissions(self):
        admin_profile = AdminProfile.objects.get(user=self.admin_user)
        self.assertTrue(admin_profile.can_manage_products)
        self.assertTrue(admin_profile.can_manage_orders)

class CustomerProfileTests(TestCase):
    """Test customer profile creation"""
    
    def setUp(self):
        self.customer_user = User.objects.create_user(
            username='customer',
            email='customer@example.com',
            password='CustomerPassword123',
            role='customer'
        )
    
    def test_customer_profile_created(self):
        self.assertTrue(
            CustomerProfile.objects.filter(user=self.customer_user).exists()
        )
    
    def test_customer_initial_loyalty_points(self):
        customer_profile = CustomerProfile.objects.get(user=self.customer_user)
        self.assertEqual(customer_profile.loyalty_points, 0)
