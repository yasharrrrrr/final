from rest_framework import serializers
from notifications.models import SMSTemplate, SMSLog, OTPCode, EmailNotification, Notification

class SMSTemplateSerializer(serializers.ModelSerializer):
    class Meta:
        model = SMSTemplate
        fields = ['id', 'template_id', 'name', 'description', 'template_type', 
                  'content', 'parameters', 'is_active']

class SMSLogSerializer(serializers.ModelSerializer):
    template_name = serializers.CharField(source='template.name', read_only=True)
    
    class Meta:
        model = SMSLog
        fields = ['id', 'recipient_phone', 'template_name', 'content', 'status',
                  'message_id', 'response_code', 'sent_at', 'delivered_at', 'created_at']

class OTPCodeSerializer(serializers.ModelSerializer):
    class Meta:
        model = OTPCode
        fields = ['id', 'phone', 'code', 'status', 'attempts', 'max_attempts',
                  'expires_at', 'verified_at', 'is_valid']
        read_only_fields = ['code', 'is_valid']

class EmailNotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmailNotification
        fields = ['id', 'recipient_email', 'subject', 'email_type', 'status',
                  'sent_at', 'created_at']

class NotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notification
        fields = ['id', 'notification_type', 'title', 'message', 'is_read',
                  'link', 'read_at', 'created_at']
        read_only_fields = ['created_at', 'read_at']
