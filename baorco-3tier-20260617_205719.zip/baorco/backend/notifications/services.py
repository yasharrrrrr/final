import requests
import logging
from datetime import timedelta
from django.utils import timezone
from django.conf import settings
from django.core.cache import cache
import random
import string

logger = logging.getLogger('baorco')

class SMSService:
    """
    Service for sending SMS via SMS.ir API
    """
    
    def __init__(self):
        self.api_url = settings.SMS_API_URL
        self.api_key = settings.SMS_API_KEY
        self.headers = {
            'Content-Type': 'application/json',
            'Accept': 'text/plain',
            'x-api-key': self.api_key
        }
    
    def send_otp(self, phone_number):
        """
        Generate and send OTP to phone number
        Returns: OTP code and SMS log
        """
        from notifications.models import OTPCode, SMSLog, SMSTemplate
        
        try:
            # Generate OTP code
            otp_code = ''.join(random.choices(string.digits, k=6))
            
            # Get or create user based on phone
            from accounts.models import User
            try:
                user = User.objects.get(phone=phone_number)
            except User.DoesNotExist:
                # Create a temporary user for new phone numbers
                username = f"user_{phone_number}"
                user = User.objects.create_user(
                    username=username,
                    phone=phone_number,
                    role='customer'
                )
            
            # Create SMS template for OTP
            template = SMSTemplate.objects.filter(
                template_id=settings.SMS_TEMPLATE_ID_OTP,
                is_active=True
            ).first()
            
            if not template:
                logger.error(f"OTP Template {settings.SMS_TEMPLATE_ID_OTP} not found")
                return None, None
            
            # Prepare SMS payload
            payload = {
                "mobile": phone_number,
                "templateId": template.template_id,
                "parameters": [
                    {"name": "Code", "value": otp_code},
                    {"name": "Time", "value": "2"}  # 2 minutes validity
                ]
            }
            
            # Send SMS
            response = requests.post(self.api_url, json=payload, headers=self.headers, timeout=10)
            
            # Create SMS log
            sms_log = SMSLog.objects.create(
                recipient_phone=phone_number,
                template=template,
                content=template.content,
                parameters=payload['parameters'],
                user=user
            )
            
            if response.status_code == 200:
                data = response.json()
                sms_log.status = 'sent'
                sms_log.message_id = data.get('data', {}).get('messageId')
                sms_log.response_code = data.get('statusCode')
                sms_log.sent_at = timezone.now()
                sms_log.save()
                
                # Create OTP record
                otp_expires = timezone.now() + timedelta(minutes=2)
                otp = OTPCode.objects.create(
                    user=user,
                    phone=phone_number,
                    code=otp_code,
                    expires_at=otp_expires,
                    sms_log=sms_log
                )
                
                logger.info(f"OTP sent successfully to {phone_number}")
                return otp_code, sms_log
            else:
                sms_log.status = 'failed'
                sms_log.response_code = response.status_code
                sms_log.response_message = response.text
                sms_log.failed_at = timezone.now()
                sms_log.save()
                
                logger.error(f"Failed to send OTP to {phone_number}: {response.text}")
                return None, None
                
        except Exception as e:
            logger.error(f"Error sending OTP: {str(e)}")
            return None, None
    
    def send_order_confirmation(self, order):
        """
        Send order confirmation SMS
        """
        from notifications.models import SMSLog, SMSTemplate
        
        try:
            phone = order.customer.phone
            if not phone:
                logger.warning(f"Customer {order.customer.id} has no phone number")
                return None
            
            template = SMSTemplate.objects.filter(
                template_id=settings.SMS_TEMPLATE_ID_ORDER,
                is_active=True
            ).first()
            
            if not template:
                logger.error(f"Order template {settings.SMS_TEMPLATE_ID_ORDER} not found")
                return None
            
            # Prepare parameters
            shamsi_date = self._gregorian_to_shamsi(order.created_at.date())
            
            payload = {
                "mobile": phone,
                "templateId": template.template_id,
                "parameters": [
                    {"name": "TIME", "value": order.created_at.strftime('%Y-%m-%d %H:%M')},
                    {"name": "QUANTITY", "value": str(sum(item.quantity for item in order.items.all()))},
                    {"name": "PRICE", "value": str(int(order.total))},
                    {"name": "YES", "value": "بله" if order.is_installment else "خیر"},
                    {"name": "DIVISION", "value": str(order.installment_months) if order.is_installment else "0"},
                    {"name": "TIME_SHAMSI", "value": shamsi_date}
                ]
            }
            
            response = requests.post(self.api_url, json=payload, headers=self.headers, timeout=10)
            
            sms_log = SMSLog.objects.create(
                recipient_phone=phone,
                template=template,
                content=template.content,
                parameters=payload['parameters'],
                user=order.customer,
                order=order
            )
            
            if response.status_code == 200:
                data = response.json()
                sms_log.status = 'sent'
                sms_log.message_id = data.get('data', {}).get('messageId')
                sms_log.response_code = data.get('statusCode')
                sms_log.sent_at = timezone.now()
                sms_log.save()
                
                logger.info(f"Order confirmation sent to {phone}")
                return sms_log
            else:
                sms_log.status = 'failed'
                sms_log.response_code = response.status_code
                sms_log.response_message = response.text
                sms_log.failed_at = timezone.now()
                sms_log.save()
                
                logger.error(f"Failed to send order confirmation: {response.text}")
                return None
                
        except Exception as e:
            logger.error(f"Error sending order confirmation: {str(e)}")
            return None
    
    def send_shipment_notification(self, order, tracking_number, status):
        """
        Send shipment status notification
        """
        from notifications.models import SMSLog, SMSTemplate
        
        try:
            phone = order.customer.phone
            if not phone:
                return None
            
            # Find a shipment template or use a custom message
            template = SMSTemplate.objects.filter(
                template_type='shipment',
                is_active=True
            ).first()
            
            message_content = f"محصولات شما با شماره پیگیری {tracking_number} ارسال شده است."
            
            sms_log = SMSLog.objects.create(
                recipient_phone=phone,
                template=template,
                content=message_content,
                user=order.customer,
                order=order
            )
            
            # For shipment, we might use a simple SMS without template
            # Or implement custom template handling
            logger.info(f"Shipment notification prepared for {phone}")
            return sms_log
            
        except Exception as e:
            logger.error(f"Error sending shipment notification: {str(e)}")
            return None
    
    def send_payment_reminder(self, installment_plan):
        """
        Send payment reminder for installment
        """
        from notifications.models import SMSLog
        
        try:
            order = installment_plan.order
            phone = order.customer.phone
            
            if not phone:
                return None
            
            message = f"یادآوری: قسط #{installment_plan.payment_number} به مبلغ {int(installment_plan.amount)} تومان تا {installment_plan.due_date} سررسید است."
            
            sms_log = SMSLog.objects.create(
                recipient_phone=phone,
                content=message,
                user=order.customer,
                order=order
            )
            
            logger.info(f"Payment reminder prepared for {phone}")
            return sms_log
            
        except Exception as e:
            logger.error(f"Error sending payment reminder: {str(e)}")
            return None
    
    @staticmethod
    def _gregorian_to_shamsi(date):
        """
        Convert Gregorian date to Shamsi (Persian) date
        """
        try:
            from jdatetime import date as jdate
            shamsi_date = jdate.fromgregorian(date=date)
            return shamsi_date.strftime('%Y/%m/%d')
        except:
            # Fallback if jdatetime is not available
            return date.strftime('%Y/%m/%d')


class EmailService:
    """
    Service for sending email notifications
    """
    
    @staticmethod
    def send_welcome_email(user):
        """Send welcome email to new user"""
        from django.core.mail import send_mail
        from notifications.models import EmailNotification
        
        try:
            subject = f"خوش‌آمدید به {settings.APP_NAME}"
            message = f"""
            سلام {user.first_name},
            
            خوش‌آمدید به {settings.APP_NAME}
            حساب کاربری شما با موفقیت ایجاد شده است.
            
            برای شروع خرید، لطفاً به حساب کاربری خود وارد شوید.
            
            با احترام،
            تیم {settings.APP_NAME}
            """
            
            send_mail(subject, message, settings.EMAIL_HOST_USER, [user.email])
            
            EmailNotification.objects.create(
                recipient_email=user.email,
                subject=subject,
                body=message,
                email_type='welcome',
                user=user,
                status='sent'
            )
            
            logger.info(f"Welcome email sent to {user.email}")
            return True
        except Exception as e:
            logger.error(f"Error sending welcome email: {str(e)}")
            return False
    
    @staticmethod
    def send_order_confirmation_email(order):
        """Send order confirmation email"""
        from django.core.mail import send_mail
        from notifications.models import EmailNotification
        
        try:
            subject = f"تأیید سفارش {order.order_number}"
            message = f"""
            سلام {order.customer.first_name},
            
            سفارش شما با موفقیت ثبت شده است.
            
            شماره سفارش: {order.order_number}
            مبلغ کل: {int(order.total)} {settings.CURRENCY}
            
            برای پیگیری سفارش خود به حساب کاربری خود مراجعه کنید.
            
            با احترام،
            تیم {settings.APP_NAME}
            """
            
            send_mail(subject, message, settings.EMAIL_HOST_USER, [order.customer.email])
            
            EmailNotification.objects.create(
                recipient_email=order.customer.email,
                subject=subject,
                body=message,
                email_type='order_confirmation',
                user=order.customer,
                order=order,
                status='sent'
            )
            
            logger.info(f"Order confirmation email sent to {order.customer.email}")
            return True
        except Exception as e:
            logger.error(f"Error sending order confirmation email: {str(e)}")
            return False


# Create singleton instances
sms_service = SMSService()
email_service = EmailService()
