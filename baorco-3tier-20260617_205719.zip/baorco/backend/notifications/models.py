from django.db import models

class SMSTemplate(models.Model):
    """
    SMS templates with placeholders
    """
    template_id = models.IntegerField(unique=True)  # SMS.ir template ID
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)
    template_type = models.CharField(
        max_length=50,
        choices=[
            ('otp', 'رمز یک بار مصرف'),
            ('order_confirmation', 'تایید سفارش'),
            ('shipment', 'اطلاع ارسالات'),
            ('payment_reminder', 'یادآوری پرداخت'),
            ('welcome', 'خوش‌آمدی'),
        ]
    )
    content = models.TextField()
    parameters = models.JSONField(help_text='List of required parameters like ["#TIME#", "#TOKEN#"]')
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'قالب پیامک'
        verbose_name_plural = 'قالب‌های پیامک'
    
    def __str__(self):
        return f"{self.name} (ID: {self.template_id})"


class SMSLog(models.Model):
    """
    Log of sent SMS messages
    """
    SMS_STATUS_CHOICES = (
        ('pending', 'در انتظار'),
        ('sent', 'ارسال شده'),
        ('failed', 'ناموفق'),
        ('delivered', 'تحویل داده شده'),
    )
    
    recipient_phone = models.CharField(max_length=20)
    template = models.ForeignKey(SMSTemplate, on_delete=models.SET_NULL, null=True)
    content = models.TextField()
    parameters = models.JSONField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=SMS_STATUS_CHOICES, default='pending')
    message_id = models.CharField(max_length=100, blank=True, null=True)  # SMS.ir message ID
    user = models.ForeignKey('accounts.User', on_delete=models.SET_NULL, null=True, blank=True)
    order = models.ForeignKey('orders.Order', on_delete=models.SET_NULL, null=True, blank=True)
    
    # Response tracking
    response_code = models.CharField(max_length=20, blank=True, null=True)
    response_message = models.TextField(blank=True, null=True)
    
    sent_at = models.DateTimeField(blank=True, null=True)
    delivered_at = models.DateTimeField(blank=True, null=True)
    failed_at = models.DateTimeField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'لاگ پیامک'
        verbose_name_plural = 'لاگ‌های پیامک'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['recipient_phone']),
            models.Index(fields=['status']),
            models.Index(fields=['created_at']),
        ]
    
    def __str__(self):
        return f"SMS to {self.recipient_phone} - {self.status}"


class OTPCode(models.Model):
    """
    One-time password codes for verification
    """
    OTP_STATUS_CHOICES = (
        ('active', 'فعال'),
        ('verified', 'تایید شده'),
        ('expired', 'منقضی شده'),
    )
    
    user = models.ForeignKey('accounts.User', on_delete=models.CASCADE, related_name='otp_codes')
    phone = models.CharField(max_length=20)
    code = models.CharField(max_length=6)
    status = models.CharField(max_length=20, choices=OTP_STATUS_CHOICES, default='active')
    attempts = models.IntegerField(default=0)
    max_attempts = models.IntegerField(default=3)
    expires_at = models.DateTimeField()
    verified_at = models.DateTimeField(blank=True, null=True)
    sms_log = models.ForeignKey(SMSLog, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'کد یک بار مصرف'
        verbose_name_plural = 'کدهای یک بار مصرف'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"OTP for {self.phone}"
    
    @property
    def is_valid(self):
        from django.utils import timezone
        return self.status == 'active' and timezone.now() < self.expires_at and self.attempts < self.max_attempts


class EmailNotification(models.Model):
    """
    Email notifications log
    """
    EMAIL_STATUS_CHOICES = (
        ('pending', 'در انتظار'),
        ('sent', 'ارسال شده'),
        ('failed', 'ناموفق'),
    )
    
    recipient_email = models.EmailField()
    subject = models.CharField(max_length=255)
    body = models.TextField()
    email_type = models.CharField(
        max_length=50,
        choices=[
            ('welcome', 'خوش‌آمدی'),
            ('order_confirmation', 'تایید سفارش'),
            ('shipment', 'اطلاع ارسالات'),
            ('payment_reminder', 'یادآوری پرداخت'),
            ('password_reset', 'تنظیم مجدد رمز'),
            ('promotional', 'تبلیغی'),
        ]
    )
    user = models.ForeignKey('accounts.User', on_delete=models.SET_NULL, null=True, blank=True)
    order = models.ForeignKey('orders.Order', on_delete=models.SET_NULL, null=True, blank=True)
    
    status = models.CharField(max_length=20, choices=EMAIL_STATUS_CHOICES, default='pending')
    error_message = models.TextField(blank=True, null=True)
    
    sent_at = models.DateTimeField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'اطلاع رسانی ایمیل'
        verbose_name_plural = 'اطلاعات رسانی ایمیل'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"Email to {self.recipient_email} - {self.email_type}"


class Notification(models.Model):
    """
    In-app notifications for users
    """
    NOTIFICATION_TYPE_CHOICES = (
        ('order', 'سفارش'),
        ('payment', 'پرداخت'),
        ('shipment', 'ارسالات'),
        ('promotion', 'تبلیغ'),
        ('system', 'سیستم'),
    )
    
    user = models.ForeignKey('accounts.User', on_delete=models.CASCADE, related_name='notifications')
    notification_type = models.CharField(max_length=50, choices=NOTIFICATION_TYPE_CHOICES)
    title = models.CharField(max_length=255)
    message = models.TextField()
    is_read = models.BooleanField(default=False)
    link = models.CharField(max_length=500, blank=True, null=True)
    order = models.ForeignKey('orders.Order', on_delete=models.SET_NULL, null=True, blank=True)
    
    read_at = models.DateTimeField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'اطلاع'
        verbose_name_plural = 'اطلاعات'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['user', '-created_at']),
            models.Index(fields=['is_read']),
        ]
    
    def __str__(self):
        return f"{self.title} - {self.user.username}"
