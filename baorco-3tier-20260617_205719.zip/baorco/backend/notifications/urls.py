from django.urls import path

urlpatterns = [
    # Notifications endpoints handled through admin and other apps
    # Can be extended with custom notification views if needed
]
