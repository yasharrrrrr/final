from django.core.management.base import BaseCommand
from notifications.models import SMSTemplate
from django.conf import settings

class Command(BaseCommand):
    help = 'Initialize SMS templates'

    def handle(self, *args, **options):
        templates = [
            {
                'template_id': settings.SMS_TEMPLATE_ID_OTP,
                'name': 'OTP Verification',
                'description': 'Template for OTP verification',
                'template_type': 'otp',
                'content': 'کد تأیید شما: #CODE# (معتبر برای 2 دقیقه)',
                'parameters': ['Code', 'Time'],
                'is_active': True,
            },
            {
                'template_id': settings.SMS_TEMPLATE_ID_ORDER,
                'name': 'Order Confirmation',
                'description': 'Template for order confirmation',
                'template_type': 'order_confirmation',
                'content': 'سفارش شما با موفقیت ثبت شد. شماره سفارش: #ORDER_ID# مبلغ: #PRICE# تومان',
                'parameters': ['ORDER_ID', 'PRICE'],
                'is_active': True,
            },
        ]
        
        for template_data in templates:
            template, created = SMSTemplate.objects.get_or_create(
                template_id=template_data['template_id'],
                defaults=template_data
            )
            
            if created:
                self.stdout.write(
                    self.style.SUCCESS(f"Template '{template.name}' created successfully")
                )
            else:
                self.stdout.write(
                    self.style.WARNING(f"Template '{template.name}' already exists")
                )
        
        self.stdout.write(self.style.SUCCESS('All templates initialized'))
