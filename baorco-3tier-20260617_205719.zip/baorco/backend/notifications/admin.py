from django.contrib import admin
from notifications.models import SMSTemplate, SMSLog, OTPCode, EmailNotification, Notification

@admin.register(SMSTemplate)
class SMSTemplateAdmin(admin.ModelAdmin):
    list_display = ('name', 'template_id', 'template_type', 'is_active')
    list_filter = ('template_type', 'is_active')
    search_fields = ('name', 'description')

@admin.register(SMSLog)
class SMSLogAdmin(admin.ModelAdmin):
    list_display = ('recipient_phone', 'template', 'status', 'sent_at')
    list_filter = ('status', 'sent_at')
    search_fields = ('recipient_phone', 'message_id')
    readonly_fields = ('created_at', 'updated_at', 'response_message')
    
    def has_add_permission(self, request):
        return False
    
    def has_change_permission(self, request, obj=None):
        return False

@admin.register(OTPCode)
class OTPCodeAdmin(admin.ModelAdmin):
    list_display = ('phone', 'status', 'attempts', 'expires_at', 'created_at')
    list_filter = ('status', 'created_at')
    search_fields = ('phone', 'user__username')
    readonly_fields = ('created_at', 'verified_at')

@admin.register(EmailNotification)
class EmailNotificationAdmin(admin.ModelAdmin):
    list_display = ('recipient_email', 'email_type', 'status', 'sent_at')
    list_filter = ('email_type', 'status', 'sent_at')
    search_fields = ('recipient_email', 'subject')
    readonly_fields = ('created_at', 'updated_at')

@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ('user', 'notification_type', 'title', 'is_read', 'created_at')
    list_filter = ('notification_type', 'is_read', 'created_at')
    search_fields = ('user__username', 'title', 'message')
    readonly_fields = ('created_at', 'read_at')
