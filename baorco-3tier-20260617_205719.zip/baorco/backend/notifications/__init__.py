# __init__.py for notifications
default_app_config = 'notifications.apps.NotificationsConfig'
