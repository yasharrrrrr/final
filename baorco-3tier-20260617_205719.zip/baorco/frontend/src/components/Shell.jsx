export function PageShell({ children }) {
  return (
    <div className="mx-auto max-w-[430px] min-h-screen pb-20">
      {children}
    </div>
  )
}

export function LoadingBlock({ label = 'در حال بارگذاری...' }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-muted text-sm gap-3">
      <div className="w-8 h-8 border-2 border-line border-t-primary rounded-full animate-spin" />
      <span>{label}</span>
    </div>
  )
}

export function EmptyState({ title, description, action }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-6 text-center gap-2">
      <p className="text-ink font-medium">{title}</p>
      {description && <p className="text-muted text-sm">{description}</p>}
      {action}
    </div>
  )
}

export function ErrorBlock({ message }) {
  return (
    <div className="mx-4 my-3 rounded-xl bg-danger/10 text-danger text-sm px-4 py-3">
      {message}
    </div>
  )
}
