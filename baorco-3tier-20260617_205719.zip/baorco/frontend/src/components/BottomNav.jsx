import { NavLink } from 'react-router-dom'
import { Home, Search, ShoppingCart, Receipt, User } from 'lucide-react'
import { useCart } from '../context/CartContext'
import { toPersianDigits } from '../utils/format'

const items = [
  { to: '/', label: 'خانه', icon: Home },
  { to: '/search', label: 'جستجو', icon: Search },
  { to: '/cart', label: 'سبد خرید', icon: ShoppingCart, badge: true },
  { to: '/orders', label: 'سفارش‌ها', icon: Receipt },
  { to: '/profile', label: 'پروفایل', icon: User },
]

export default function BottomNav() {
  const { itemCount } = useCart()

  return (
    <nav className="fixed bottom-0 inset-x-0 z-40 border-t border-line bg-surface/95 backdrop-blur-sm">
      <div className="mx-auto max-w-[430px] grid grid-cols-5">
        {items.map(({ to, label, icon: Icon, badge }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              `relative flex flex-col items-center gap-1 py-2.5 text-[11px] ${
                isActive ? 'text-primary' : 'text-muted'
              }`
            }
          >
            <Icon size={22} strokeWidth={2} />
            {badge && itemCount > 0 && (
              <span className="absolute top-1 right-[28%] min-w-[16px] h-4 px-1 rounded-full bg-accent text-white text-[10px] flex items-center justify-center leading-none">
                {toPersianDigits(itemCount)}
              </span>
            )}
            <span>{label}</span>
          </NavLink>
        ))}
      </div>
    </nav>
  )
}
