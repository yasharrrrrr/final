import { Link } from 'react-router-dom'
import { ShoppingCart } from 'lucide-react'
import { useCart } from '../context/CartContext'
import { toPersianDigits } from '../utils/format'

export default function Header({ title }) {
  const { itemCount } = useCart()

  return (
    <header className="sticky top-0 z-30 bg-bg/95 backdrop-blur-sm border-b border-line">
      <div className="mx-auto max-w-[430px] px-4 h-14 flex items-center justify-between">
        <Link to="/" className="flex items-baseline gap-1">
          <span className="text-lg font-bold text-primary">باورکو</span>
          <span className="text-[11px] text-muted">مبلمان</span>
        </Link>
        {title && <h1 className="text-sm font-semibold text-ink truncate">{title}</h1>}
        <Link to="/cart" className="relative p-2 -m-2 text-ink">
          <ShoppingCart size={22} />
          {itemCount > 0 && (
            <span className="absolute top-0 right-0 min-w-[16px] h-4 px-1 rounded-full bg-accent text-white text-[10px] flex items-center justify-center leading-none">
              {toPersianDigits(itemCount)}
            </span>
          )}
        </Link>
      </div>
    </header>
  )
}
