import { Link } from 'react-router-dom'
import { Star } from 'lucide-react'
import { formatPrice, toPersianDigits } from '../utils/format'

export default function ProductCard({ product }) {
  const hasDiscount = !!product.discounted_price
  const price = hasDiscount ? product.discounted_price : product.base_price

  return (
    <Link
      to={`/product/${product.id}`}
      className="block bg-surface rounded-xl2 border border-line overflow-hidden hover:shadow-md transition-shadow"
    >
      <div className="relative aspect-square bg-line/40 chamfer-corner overflow-hidden">
        {product.image ? (
          <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-muted text-xs">
            بدون تصویر
          </div>
        )}
        {hasDiscount && (
          <span className="absolute top-2 left-2 bg-danger text-white text-[10px] px-1.5 py-0.5 rounded-md">
            تخفیف
          </span>
        )}
      </div>
      <div className="p-3">
        <h3 className="text-sm font-medium text-ink line-clamp-2 min-h-[2.5em]">{product.name}</h3>
        <div className="flex items-center gap-1 mt-1 text-[11px] text-muted">
          <Star size={12} className="fill-accent text-accent" />
          <span>{toPersianDigits(Number(product.rating || 0).toFixed(1))}</span>
        </div>
        <div className="mt-2 flex items-baseline gap-2">
          <span className="text-sm font-bold text-primary">{formatPrice(price)}</span>
          {hasDiscount && (
            <span className="text-[11px] text-muted line-through">{formatPrice(product.base_price)}</span>
          )}
        </div>
      </div>
    </Link>
  )
}
