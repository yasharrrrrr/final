import { createContext, useContext, useState, useCallback } from 'react'
import * as cartApi from '../api/cart'
import { useAuth } from './AuthContext'

const CartContext = createContext(null)

export function CartProvider({ children }) {
  const { user } = useAuth()
  const [cart, setCart] = useState(null)
  const [loading, setLoading] = useState(false)

  const refresh = useCallback(async () => {
    if (!user) {
      setCart(null)
      return
    }
    setLoading(true)
    try {
      const data = await cartApi.getCart()
      setCart(data)
    } finally {
      setLoading(false)
    }
  }, [user])

  async function addItem(productId, quantity = 1) {
    const data = await cartApi.addItem(productId, quantity)
    setCart(data)
  }

  async function updateItem(cartItemId, quantity) {
    const data = await cartApi.updateItem(cartItemId, quantity)
    setCart(data)
  }

  async function removeItem(cartItemId) {
    const data = await cartApi.removeItem(cartItemId)
    setCart(data)
  }

  async function clear() {
    await cartApi.clearCart()
    setCart((prev) => (prev ? { ...prev, items: [], total_items: 0, total_price: 0 } : prev))
  }

  const itemCount = cart?.items?.reduce((sum, i) => sum + i.quantity, 0) || 0

  return (
    <CartContext.Provider
      value={{ cart, loading, itemCount, refresh, addItem, updateItem, removeItem, clear }}
    >
      {children}
    </CartContext.Provider>
  )
}

export function useCart() {
  const ctx = useContext(CartContext)
  if (!ctx) throw new Error('useCart must be used within CartProvider')
  return ctx
}
