import jalaali from 'jalaali-js'

const PERSIAN_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹']

export function toPersianDigits(value) {
  return String(value).replace(/[0-9]/g, (d) => PERSIAN_DIGITS[Number(d)])
}

export function formatPrice(value) {
  const num = Math.round(Number(value) || 0)
  const withCommas = num.toLocaleString('en-US')
  return `${toPersianDigits(withCommas)} تومان`
}

export function formatNumber(value) {
  return toPersianDigits(Number(value).toLocaleString('en-US'))
}

const PERSIAN_MONTHS = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
]

export function formatShamsiDate(isoString) {
  if (!isoString) return ''
  const d = new Date(isoString)
  const { jy, jm, jd } = jalaali.toJalaali(d.getFullYear(), d.getMonth() + 1, d.getDate())
  return `${toPersianDigits(jd)} ${PERSIAN_MONTHS[jm - 1]} ${toPersianDigits(jy)}`
}
