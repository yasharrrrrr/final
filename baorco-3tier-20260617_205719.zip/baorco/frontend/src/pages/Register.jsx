import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { ErrorBlock } from '../components/Shell'

export default function Register() {
  const { register } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({
    username: '', email: '', phone: '', password: '', password2: '',
  })
  const [error, setError] = useState('')
  const [submitting, setSubmitting] = useState(false)

  function update(field) {
    return (e) => setForm((f) => ({ ...f, [field]: e.target.value }))
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    if (form.password !== form.password2) {
      setError('رمز عبور و تکرار آن یکسان نیستند')
      return
    }
    setSubmitting(true)
    try {
      await register(form)
      navigate('/', { replace: true })
    } catch (err) {
      const data = err.response?.data
      setError(typeof data === 'object' ? Object.values(data).flat().join(' / ') : 'خطا در ثبت‌نام')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="mx-auto max-w-[430px] min-h-screen flex flex-col px-6 py-10">
      <div className="mb-8 text-center">
        <h1 className="text-2xl font-bold text-primary">ساخت حساب کاربری</h1>
      </div>

      {error && <ErrorBlock message={error} />}

      <form onSubmit={handleSubmit} className="flex flex-col gap-3.5">
        <Field label="نام کاربری" value={form.username} onChange={update('username')} required />
        <Field label="ایمیل" type="email" value={form.email} onChange={update('email')} />
        <Field label="شماره موبایل" value={form.phone} onChange={update('phone')} placeholder="09xxxxxxxxx" required />
        <Field label="رمز عبور" type="password" value={form.password} onChange={update('password')} required />
        <Field label="تکرار رمز عبور" type="password" value={form.password2} onChange={update('password2')} required />

        <button
          type="submit"
          disabled={submitting}
          className="mt-2 w-full rounded-xl bg-primary text-white py-3 text-sm font-medium disabled:opacity-60"
        >
          {submitting ? 'در حال ثبت‌نام...' : 'ثبت‌نام'}
        </button>
      </form>

      <p className="text-center text-sm text-muted mt-6">
        قبلاً ثبت‌نام کرده‌اید؟{' '}
        <Link to="/login" className="text-primary font-medium">ورود</Link>
      </p>
    </div>
  )
}

function Field({ label, ...props }) {
  return (
    <div>
      <label className="block text-sm text-ink mb-1.5">{label}</label>
      <input
        {...props}
        className="w-full rounded-xl border border-line bg-surface px-4 py-3 text-sm outline-none focus:border-primary"
      />
    </div>
  )
}
