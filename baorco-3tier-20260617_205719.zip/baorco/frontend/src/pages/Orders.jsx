import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { ChevronLeft } from 'lucide-react'
import Header from '../components/Header'
import { PageShell, LoadingBlock, EmptyState } from '../components/Shell'
import { listOrders } from '../api/orders'
import { formatPrice, formatShamsiDate } from '../utils/format'

const STATUS_LABELS = {
  pending: 'در انتظار تأیید',
  confirmed: 'تأیید شده',
  processing: 'در حال پردازش',
  shipped: 'ارسال شده',
  delivered: 'تحویل شده',
  cancelled: 'لغو شده',
}

export default function Orders() {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let active = true
    listOrders()
      .then((data) => active && setOrders(Array.isArray(data) ? data : data.results || []))
      .finally(() => active && setLoading(false))
    return () => { active = false }
  }, [])

  return (
    <PageShell>
      <Header title="سفارش‌های من" />

      {loading ? (
        <LoadingBlock />
      ) : orders.length === 0 ? (
        <EmptyState title="هنوز سفارشی ثبت نکرده‌اید" />
      ) : (
        <div className="px-4 pt-4 flex flex-col gap-3">
          {orders.map((order) => (
            <Link
              key={order.id}
              to={`/orders/${order.id}`}
              className="flex items-center gap-3 border border-line rounded-xl p-3"
            >
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-ink">سفارش {order.order_number}</p>
                <p className="text-xs text-muted mt-1">{formatShamsiDate(order.created_at)}</p>
                <p className="text-xs text-accent mt-1">{STATUS_LABELS[order.status] || order.status}</p>
              </div>
              <span className="text-sm font-bold text-primary">{formatPrice(order.total)}</span>
              <ChevronLeft size={18} className="text-muted" />
            </Link>
          ))}
        </div>
      )}
    </PageShell>
  )
}
