import { useEffect, useState } from 'react'
import { ArrowRight } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { PageShell, LoadingBlock, EmptyState } from '../components/Shell'
import ProductCard from '../components/ProductCard'
import { listWishlist } from '../api/products'

export default function Wishlist() {
  const navigate = useNavigate()
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let active = true
    listWishlist()
      .then((data) => active && setItems(Array.isArray(data) ? data : data.results || []))
      .finally(() => active && setLoading(false))
    return () => { active = false }
  }, [])

  return (
    <PageShell>
      <div className="sticky top-0 z-30 bg-bg/95 backdrop-blur-sm border-b border-line">
        <div className="mx-auto max-w-[430px] px-4 h-14 flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="p-1 -m-1">
            <ArrowRight size={20} />
          </button>
          <span className="text-sm font-medium">لیست آرزوها</span>
        </div>
      </div>

      {loading ? (
        <LoadingBlock />
      ) : items.length === 0 ? (
        <EmptyState title="لیست آرزوهای شما خالی است" />
      ) : (
        <div className="px-4 pt-4 grid grid-cols-2 gap-3">
          {items.map((item) => (
            <ProductCard key={item.id} product={item.product} />
          ))}
        </div>
      )}
    </PageShell>
  )
}
