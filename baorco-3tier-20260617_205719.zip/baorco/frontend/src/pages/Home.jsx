import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import Header from '../components/Header'
import ProductCard from '../components/ProductCard'
import { PageShell, LoadingBlock } from '../components/Shell'
import { listFeatured, listBestsellers, listCategories } from '../api/products'

export default function Home() {
  const [categories, setCategories] = useState([])
  const [featured, setFeatured] = useState([])
  const [bestsellers, setBestsellers] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let active = true
    Promise.all([listCategories(), listFeatured(), listBestsellers()])
      .then(([cats, feat, best]) => {
        if (!active) return
        setCategories(Array.isArray(cats) ? cats : cats.results || [])
        setFeatured(feat)
        setBestsellers(best)
      })
      .finally(() => active && setLoading(false))
    return () => { active = false }
  }, [])

  return (
    <PageShell>
      <Header />

      <section className="px-4 pt-4">
        <div className="rounded-xl2 bg-primary text-white p-5 relative overflow-hidden">
          <h2 className="text-lg font-bold leading-relaxed">
            مبلمانی که داستان خانه شما را می‌سازد
          </h2>
          <p className="text-white/80 text-sm mt-1">ساخت دست، طراحی امروزی</p>
          <div className="brand-divider mt-4 opacity-80" />
        </div>
      </section>

      {loading ? (
        <LoadingBlock />
      ) : (
        <>
          {categories.length > 0 && (
            <section className="px-4 mt-6">
              <h3 className="text-sm font-semibold text-ink mb-3">دسته‌بندی‌ها</h3>
              <div className="flex gap-3 overflow-x-auto pb-1 -mx-4 px-4">
                {categories.map((c) => (
                  <Link
                    key={c.id}
                    to={`/search?category=${c.id}`}
                    className="flex-shrink-0 px-4 py-2 rounded-full border border-line bg-surface text-sm text-ink whitespace-nowrap"
                  >
                    {c.name}
                  </Link>
                ))}
              </div>
            </section>
          )}

          {featured.length > 0 && (
            <ProductRail title="منتخب باورکو" products={featured} />
          )}

          {bestsellers.length > 0 && (
            <ProductRail title="پرفروش‌ترین‌ها" products={bestsellers} />
          )}
        </>
      )}
    </PageShell>
  )
}

function ProductRail({ title, products }) {
  return (
    <section className="px-4 mt-6">
      <h3 className="text-sm font-semibold text-ink mb-3">{title}</h3>
      <div className="grid grid-cols-2 gap-3">
        {products.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </section>
  )
}
