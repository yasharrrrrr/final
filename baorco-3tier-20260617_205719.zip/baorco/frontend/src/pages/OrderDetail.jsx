import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { ArrowRight, Truck } from 'lucide-react'
import { PageShell, LoadingBlock, ErrorBlock } from '../components/Shell'
import { getOrder, cancelOrder } from '../api/orders'
import { formatPrice, formatShamsiDate } from '../utils/format'

const STATUS_LABELS = {
  pending: 'در انتظار تأیید',
  confirmed: 'تأیید شده',
  processing: 'در حال پردازش',
  shipped: 'ارسال شده',
  delivered: 'تحویل شده',
  cancelled: 'لغو شده',
}

export default function OrderDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [order, setOrder] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    let active = true
    getOrder(id)
      .then((data) => active && setOrder(data))
      .catch(() => active && setError('سفارش یافت نشد'))
      .finally(() => active && setLoading(false))
    return () => { active = false }
  }, [id])

  async function handleCancel() {
    try {
      await cancelOrder(id)
      const refreshed = await getOrder(id)
      setOrder(refreshed)
    } catch {
      setError('امکان لغو این سفارش وجود ندارد')
    }
  }

  if (loading) return <PageShell><LoadingBlock /></PageShell>
  if (error || !order) return <PageShell><ErrorBlock message={error || 'سفارش یافت نشد'} /></PageShell>

  const canCancel = ['pending', 'confirmed'].includes(order.status)

  return (
    <PageShell>
      <div className="sticky top-0 z-30 bg-bg/95 backdrop-blur-sm border-b border-line">
        <div className="mx-auto max-w-[430px] px-4 h-14 flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="p-1 -m-1">
            <ArrowRight size={20} />
          </button>
          <span className="text-sm font-medium">سفارش {order.order_number}</span>
        </div>
      </div>

      <div className="px-4 pt-4">
        <div className="flex items-center justify-between">
          <span className="text-sm text-accent font-medium">{STATUS_LABELS[order.status] || order.status}</span>
          <span className="text-xs text-muted">{formatShamsiDate(order.created_at)}</span>
        </div>

        {order.tracking_number && (
          <div className="flex items-center gap-2 mt-3 text-sm text-ink bg-line/30 rounded-xl px-3 py-2.5">
            <Truck size={16} className="text-primary" />
            <span>کد رهگیری: {order.tracking_number}</span>
          </div>
        )}

        <div className="brand-divider my-4" />

        <h2 className="text-sm font-semibold mb-3">اقلام سفارش</h2>
        <div className="flex flex-col gap-2">
          {order.items?.map((item) => (
            <div key={item.id} className="flex justify-between text-sm">
              <span className="text-ink">{item.product_name} × {item.quantity}</span>
              <span className="text-muted">{formatPrice(item.total_price)}</span>
            </div>
          ))}
        </div>

        <div className="brand-divider my-4" />

        <div className="flex flex-col gap-1.5 text-sm">
          <Row label="جمع جزء" value={formatPrice(order.subtotal)} />
          {Number(order.discount_amount) > 0 && <Row label="تخفیف" value={`- ${formatPrice(order.discount_amount)}`} />}
          <Row label="هزینه ارسال" value={formatPrice(order.shipping_cost)} />
          <Row label="مالیات" value={formatPrice(order.tax)} />
          <Row label="مبلغ کل" value={formatPrice(order.total)} strong />
        </div>

        {order.is_installment && (
          <p className="text-xs text-accent mt-2">
            پرداخت اقساطی: {order.installment_months} ماهه · {formatPrice(order.monthly_payment)} در ماه
          </p>
        )}

        <div className="brand-divider my-4" />

        <h2 className="text-sm font-semibold mb-2">آدرس ارسال</h2>
        <p className="text-sm text-ink">{order.shipping_address}، {order.shipping_city}</p>
        <p className="text-sm text-muted">{order.shipping_phone}</p>

        {canCancel && (
          <button
            onClick={handleCancel}
            className="mt-6 w-full rounded-xl border border-danger text-danger py-3 text-sm font-medium"
          >
            لغو سفارش
          </button>
        )}
      </div>
    </PageShell>
  )
}

function Row({ label, value, strong }) {
  return (
    <div className="flex justify-between">
      <span className={strong ? 'font-bold text-ink' : 'text-muted'}>{label}</span>
      <span className={strong ? 'font-bold text-primary text-base' : 'text-ink'}>{value}</span>
    </div>
  )
}
