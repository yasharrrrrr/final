import { useState } from 'react'
import { useNavigate, useLocation, Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { ErrorBlock } from '../components/Shell'

export default function Login() {
  const { login } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [submitting, setSubmitting] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    setSubmitting(true)
    try {
      await login(username, password)
      navigate(location.state?.from?.pathname || '/', { replace: true })
    } catch (err) {
      setError(err.response?.data?.detail || 'نام کاربری یا رمز عبور اشتباه است')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="mx-auto max-w-[430px] min-h-screen flex flex-col px-6 py-10">
      <div className="mb-10 text-center">
        <h1 className="text-2xl font-bold text-primary">باورکو</h1>
        <p className="text-muted text-sm mt-1">فروشگاه آنلاین مبلمان</p>
      </div>

      {error && <ErrorBlock message={error} />}

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <div>
          <label className="block text-sm text-ink mb-1.5">نام کاربری</label>
          <input
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full rounded-xl border border-line bg-surface px-4 py-3 text-sm outline-none focus:border-primary"
            required
          />
        </div>
        <div>
          <label className="block text-sm text-ink mb-1.5">رمز عبور</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full rounded-xl border border-line bg-surface px-4 py-3 text-sm outline-none focus:border-primary"
            required
          />
        </div>
        <button
          type="submit"
          disabled={submitting}
          className="mt-2 w-full rounded-xl bg-primary text-white py-3 text-sm font-medium disabled:opacity-60"
        >
          {submitting ? 'در حال ورود...' : 'ورود'}
        </button>
      </form>

      <p className="text-center text-sm text-muted mt-6">
        حساب کاربری ندارید؟{' '}
        <Link to="/register" className="text-primary font-medium">
          ثبت‌نام
        </Link>
      </p>
    </div>
  )
}
