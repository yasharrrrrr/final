import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { LogOut, Heart, ChevronLeft, KeyRound } from 'lucide-react'
import Header from '../components/Header'
import { PageShell, ErrorBlock } from '../components/Shell'
import { useAuth } from '../context/AuthContext'
import { changePassword } from '../api/auth'

export default function Profile() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const [showPasswordForm, setShowPasswordForm] = useState(false)
  const [passwords, setPasswords] = useState({ old_password: '', new_password: '' })
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')

  function handleLogout() {
    logout()
    navigate('/login', { replace: true })
  }

  async function handlePasswordSubmit(e) {
    e.preventDefault()
    setError('')
    setMessage('')
    try {
      await changePassword(passwords)
      setMessage('رمز عبور با موفقیت تغییر یافت')
      setPasswords({ old_password: '', new_password: '' })
      setShowPasswordForm(false)
    } catch {
      setError('رمز عبور فعلی نادرست است')
    }
  }

  return (
    <PageShell>
      <Header title="پروفایل" />

      <div className="px-4 pt-4">
        <div className="border border-line rounded-xl p-4">
          <p className="font-semibold text-ink">{user?.first_name} {user?.last_name || user?.username}</p>
          <p className="text-sm text-muted mt-0.5">{user?.email}</p>
          <p className="text-sm text-muted">{user?.phone}</p>
        </div>

        {message && <p className="text-sm text-primary mt-3">{message}</p>}
        {error && <ErrorBlock message={error} />}

        <div className="mt-4 flex flex-col divide-y divide-line border border-line rounded-xl overflow-hidden">
          <MenuRow icon={Heart} label="لیست آرزوها" onClick={() => navigate('/wishlist')} />
          <MenuRow icon={KeyRound} label="تغییر رمز عبور" onClick={() => setShowPasswordForm((v) => !v)} />
        </div>

        {showPasswordForm && (
          <form onSubmit={handlePasswordSubmit} className="mt-3 flex flex-col gap-3 border border-line rounded-xl p-4">
            <input
              type="password"
              placeholder="رمز عبور فعلی"
              value={passwords.old_password}
              onChange={(e) => setPasswords((p) => ({ ...p, old_password: e.target.value }))}
              className="rounded-lg border border-line px-3 py-2.5 text-sm outline-none focus:border-primary"
              required
            />
            <input
              type="password"
              placeholder="رمز عبور جدید"
              value={passwords.new_password}
              onChange={(e) => setPasswords((p) => ({ ...p, new_password: e.target.value }))}
              className="rounded-lg border border-line px-3 py-2.5 text-sm outline-none focus:border-primary"
              required
            />
            <button type="submit" className="rounded-lg bg-primary text-white py-2.5 text-sm font-medium">
              ذخیره تغییرات
            </button>
          </form>
        )}

        <button
          onClick={handleLogout}
          className="mt-6 w-full flex items-center justify-center gap-2 rounded-xl border border-danger text-danger py-3 text-sm font-medium"
        >
          <LogOut size={16} />
          خروج از حساب کاربری
        </button>
      </div>
    </PageShell>
  )
}

function MenuRow({ icon: Icon, label, onClick }) {
  return (
    <button onClick={onClick} className="flex items-center gap-3 px-4 py-3.5 text-sm text-ink bg-surface">
      <Icon size={18} className="text-primary" />
      <span className="flex-1 text-right">{label}</span>
      <ChevronLeft size={16} className="text-muted" />
    </button>
  )
}
