import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { ArrowRight, Star, Heart } from 'lucide-react'
import Header from '../components/Header'
import { PageShell, LoadingBlock, ErrorBlock } from '../components/Shell'
import { getProduct, getReviews, addToWishlist } from '../api/products'
import { useCart } from '../context/CartContext'
import { useAuth } from '../context/AuthContext'
import { formatPrice, toPersianDigits, formatShamsiDate } from '../utils/format'

export default function ProductDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { user } = useAuth()
  const { addItem } = useCart()

  const [product, setProduct] = useState(null)
  const [reviews, setReviews] = useState([])
  const [loading, setLoading] = useState(true)
  const [adding, setAdding] = useState(false)
  const [message, setMessage] = useState('')

  useEffect(() => {
    let active = true
    setLoading(true)
    Promise.all([getProduct(id), getReviews(id)])
      .then(([p, r]) => {
        if (!active) return
        setProduct(p)
        setReviews(r)
      })
      .finally(() => active && setLoading(false))
    return () => { active = false }
  }, [id])

  async function handleAddToCart() {
    if (!user) return navigate('/login')
    setAdding(true)
    setMessage('')
    try {
      await addItem(product.id, 1)
      setMessage('به سبد خرید اضافه شد')
    } catch {
      setMessage('خطا در افزودن به سبد خرید')
    } finally {
      setAdding(false)
    }
  }

  async function handleWishlist() {
    if (!user) return navigate('/login')
    try {
      await addToWishlist(product.id)
      setMessage('به لیست آرزو اضافه شد')
    } catch {
      setMessage('قبلاً اضافه شده است')
    }
  }

  if (loading) return <PageShell><Header /><LoadingBlock /></PageShell>
  if (!product) return <PageShell><Header /><ErrorBlock message="محصول یافت نشد" /></PageShell>

  const hasDiscount = !!product.discounted_price
  const price = hasDiscount ? product.discounted_price : product.base_price

  return (
    <PageShell>
      <div className="sticky top-0 z-30 bg-bg/95 backdrop-blur-sm border-b border-line">
        <div className="mx-auto max-w-[430px] px-4 h-14 flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="p-1 -m-1">
            <ArrowRight size={20} />
          </button>
          <span className="text-sm font-medium truncate">{product.name}</span>
        </div>
      </div>

      <div className="aspect-square bg-line/40">
        {product.image && (
          <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
        )}
      </div>

      <div className="px-4 pt-4">
        <h1 className="text-lg font-bold text-ink">{product.name}</h1>
        <div className="flex items-center gap-1 mt-1 text-sm text-muted">
          <Star size={14} className="fill-accent text-accent" />
          <span>{toPersianDigits(Number(product.rating || 0).toFixed(1))}</span>
          <span>· {toPersianDigits(reviews.length)} نظر</span>
        </div>

        <div className="flex items-baseline gap-2 mt-3">
          <span className="text-xl font-bold text-primary">{formatPrice(price)}</span>
          {hasDiscount && (
            <span className="text-sm text-muted line-through">{formatPrice(product.base_price)}</span>
          )}
        </div>

        {product.allows_installment && (
          <p className="text-xs text-accent mt-1">امکان خرید اقساطی</p>
        )}

        <div className="brand-divider my-4" />

        <p className="text-sm text-ink leading-relaxed whitespace-pre-line">
          {product.description || product.detailed_description}
        </p>

        {message && <p className="text-sm text-primary mt-3">{message}</p>}

        <div className="flex gap-2 mt-5">
          <button
            onClick={handleAddToCart}
            disabled={adding}
            className="flex-1 rounded-xl bg-primary text-white py-3 text-sm font-medium disabled:opacity-60"
          >
            {adding ? 'در حال افزودن...' : 'افزودن به سبد خرید'}
          </button>
          <button
            onClick={handleWishlist}
            className="w-12 h-12 flex items-center justify-center rounded-xl border border-line"
          >
            <Heart size={18} className="text-primary" />
          </button>
        </div>

        <div className="brand-divider my-6" />

        <h2 className="text-sm font-semibold text-ink mb-3">نظرات کاربران</h2>
        {reviews.length === 0 ? (
          <p className="text-sm text-muted">هنوز نظری ثبت نشده است</p>
        ) : (
          <div className="flex flex-col gap-3">
            {reviews.map((r) => (
              <div key={r.id} className="border border-line rounded-xl p-3">
                <div className="flex items-center gap-1 text-xs text-muted">
                  <Star size={12} className="fill-accent text-accent" />
                  <span>{toPersianDigits(r.rating)}</span>
                  <span className="mr-auto">{formatShamsiDate(r.created_at)}</span>
                </div>
                {r.title && <p className="text-sm font-medium mt-1.5">{r.title}</p>}
                <p className="text-sm text-ink mt-1">{r.review}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </PageShell>
  )
}
