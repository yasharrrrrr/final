import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'
import { PageShell, ErrorBlock } from '../components/Shell'
import { useCart } from '../context/CartContext'
import { createOrder } from '../api/orders'
import { formatPrice } from '../utils/format'

const PAYMENT_METHODS = [
  { value: 'cash', label: 'پرداخت نقدی' },
  { value: 'card', label: 'کارت بانکی' },
  { value: 'installment', label: 'پرداخت اقساطی' },
]

export default function Checkout() {
  const navigate = useNavigate()
  const { cart, clear } = useCart()
  const [form, setForm] = useState({
    shipping_address: '',
    shipping_city: '',
    shipping_postal_code: '',
    shipping_phone: '',
    payment_method: 'cash',
    is_installment: false,
    installment_months: 6,
    notes: '',
  })
  const [error, setError] = useState('')
  const [submitting, setSubmitting] = useState(false)

  function update(field) {
    return (e) => {
      const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value
      setForm((f) => ({ ...f, [field]: value }))
    }
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    setSubmitting(true)
    try {
      const order = await createOrder(form)
      await clear()
      navigate(`/orders/${order.id}`, { replace: true })
    } catch (err) {
      const data = err.response?.data
      setError(typeof data === 'object' ? Object.values(data).flat().join(' / ') : 'خطا در ثبت سفارش')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <PageShell>
      <div className="sticky top-0 z-30 bg-bg/95 backdrop-blur-sm border-b border-line">
        <div className="mx-auto max-w-[430px] px-4 h-14 flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="p-1 -m-1">
            <ArrowRight size={20} />
          </button>
          <span className="text-sm font-medium">نهایی کردن سفارش</span>
        </div>
      </div>

      {error && <ErrorBlock message={error} />}

      <form onSubmit={handleSubmit} className="px-4 pt-4 flex flex-col gap-3.5">
        <Field label="آدرس کامل" value={form.shipping_address} onChange={update('shipping_address')} required />
        <div className="grid grid-cols-2 gap-3">
          <Field label="شهر" value={form.shipping_city} onChange={update('shipping_city')} required />
          <Field label="کد پستی" value={form.shipping_postal_code} onChange={update('shipping_postal_code')} />
        </div>
        <Field label="شماره تماس" value={form.shipping_phone} onChange={update('shipping_phone')} required />

        <div>
          <label className="block text-sm text-ink mb-1.5">روش پرداخت</label>
          <div className="flex flex-col gap-2">
            {PAYMENT_METHODS.map((m) => (
              <label
                key={m.value}
                className={`flex items-center gap-2 border rounded-xl px-4 py-3 text-sm cursor-pointer ${
                  form.payment_method === m.value ? 'border-primary bg-primary/5' : 'border-line'
                }`}
              >
                <input
                  type="radio"
                  name="payment_method"
                  value={m.value}
                  checked={form.payment_method === m.value}
                  onChange={(e) =>
                    setForm((f) => ({
                      ...f,
                      payment_method: e.target.value,
                      is_installment: e.target.value === 'installment',
                    }))
                  }
                />
                {m.label}
              </label>
            ))}
          </div>
        </div>

        {form.is_installment && (
          <Field
            label="تعداد ماه‌های اقساط"
            type="number"
            min="2"
            max="24"
            value={form.installment_months}
            onChange={update('installment_months')}
          />
        )}

        <Field label="یادداشت (اختیاری)" value={form.notes} onChange={update('notes')} />

        <div className="brand-divider my-2" />
        <div className="flex items-center justify-between text-sm">
          <span>جمع کل</span>
          <span className="font-bold text-primary text-base">{formatPrice(cart?.total_price || 0)}</span>
        </div>

        <button
          type="submit"
          disabled={submitting}
          className="mt-2 w-full rounded-xl bg-primary text-white py-3 text-sm font-medium disabled:opacity-60"
        >
          {submitting ? 'در حال ثبت سفارش...' : 'ثبت نهایی سفارش'}
        </button>
      </form>
    </PageShell>
  )
}

function Field({ label, ...props }) {
  return (
    <div>
      <label className="block text-sm text-ink mb-1.5">{label}</label>
      <input
        {...props}
        className="w-full rounded-xl border border-line bg-surface px-4 py-3 text-sm outline-none focus:border-primary"
      />
    </div>
  )
}
