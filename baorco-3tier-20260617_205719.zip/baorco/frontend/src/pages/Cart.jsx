import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { Minus, Plus, Trash2 } from 'lucide-react'
import Header from '../components/Header'
import { PageShell, LoadingBlock, EmptyState } from '../components/Shell'
import { useCart } from '../context/CartContext'
import { formatPrice } from '../utils/format'

export default function CartPage() {
  const navigate = useNavigate()
  const { cart, loading, refresh, updateItem, removeItem } = useCart()

  useEffect(() => { refresh() }, [refresh])

  if (loading) return <PageShell><Header title="سبد خرید" /><LoadingBlock /></PageShell>

  const items = cart?.items || []

  if (items.length === 0) {
    return (
      <PageShell>
        <Header title="سبد خرید" />
        <EmptyState
          title="سبد خرید شما خالی است"
          description="محصولات مورد علاقه خود را اضافه کنید"
          action={
            <button onClick={() => navigate('/')} className="mt-3 rounded-xl bg-primary text-white px-5 py-2.5 text-sm">
              مشاهده محصولات
            </button>
          }
        />
      </PageShell>
    )
  }

  return (
    <PageShell>
      <Header title="سبد خرید" />

      <div className="px-4 pt-4 flex flex-col gap-3">
        {items.map((item) => (
          <div key={item.id} className="flex gap-3 border border-line rounded-xl p-3">
            <div className="w-16 h-16 bg-line/40 rounded-lg flex-shrink-0 overflow-hidden">
              {item.product_image && (
                <img src={item.product_image} alt="" className="w-full h-full object-cover" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-ink truncate">{item.product_name}</p>
              <p className="text-sm text-primary font-bold mt-1">{formatPrice(item.price)}</p>
              <div className="flex items-center gap-2 mt-2">
                <button
                  onClick={() => updateItem(item.id, item.quantity - 1)}
                  className="w-7 h-7 flex items-center justify-center rounded-lg border border-line"
                >
                  <Minus size={14} />
                </button>
                <span className="text-sm w-6 text-center">{item.quantity}</span>
                <button
                  onClick={() => updateItem(item.id, item.quantity + 1)}
                  className="w-7 h-7 flex items-center justify-center rounded-lg border border-line"
                >
                  <Plus size={14} />
                </button>
                <button onClick={() => removeItem(item.id)} className="mr-auto text-danger p-1">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="px-4 mt-6">
        <div className="brand-divider mb-4" />
        <div className="flex items-center justify-between text-sm text-ink mb-4">
          <span>جمع کل</span>
          <span className="font-bold text-primary text-base">{formatPrice(cart.total_price)}</span>
        </div>
        <button
          onClick={() => navigate('/checkout')}
          className="w-full rounded-xl bg-primary text-white py-3 text-sm font-medium"
        >
          ادامه فرایند خرید
        </button>
      </div>
    </PageShell>
  )
}
