import { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { Search as SearchIcon } from 'lucide-react'
import Header from '../components/Header'
import ProductCard from '../components/ProductCard'
import { PageShell, LoadingBlock, EmptyState } from '../components/Shell'
import { listProducts } from '../api/products'

export default function Search() {
  const [params, setParams] = useSearchParams()
  const [query, setQuery] = useState(params.get('q') || '')
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let active = true
    setLoading(true)
    const apiParams = {}
    if (params.get('q')) apiParams.search = params.get('q')
    if (params.get('category')) apiParams.category = params.get('category')

    listProducts(apiParams)
      .then((data) => active && setProducts(Array.isArray(data) ? data : data.results || []))
      .finally(() => active && setLoading(false))
    return () => { active = false }
  }, [params])

  function handleSubmit(e) {
    e.preventDefault()
    setParams(query ? { q: query } : {})
  }

  return (
    <PageShell>
      <Header title="جستجوی محصولات" />

      <form onSubmit={handleSubmit} className="px-4 pt-4">
        <div className="flex items-center gap-2 rounded-xl border border-line bg-surface px-3 py-2.5">
          <SearchIcon size={18} className="text-muted" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="جستجوی مبل، میز، صندلی..."
            className="flex-1 bg-transparent outline-none text-sm"
          />
        </div>
      </form>

      <section className="px-4 mt-4">
        {loading ? (
          <LoadingBlock />
        ) : products.length === 0 ? (
          <EmptyState title="نتیجه‌ای یافت نشد" description="عبارت دیگری را جستجو کنید" />
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {products.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </section>
    </PageShell>
  )
}
