import { client, setTokens, getTokens } from './client'

export async function login(username, password) {
  const { data } = await client.post('/auth/login/', { username, password })
  setTokens({ access: data.access, refresh: data.refresh })
  return data
}

export async function register(payload) {
  const { data } = await client.post('/auth/register/', payload)
  return data
}

export function logout() {
  setTokens(null)
}

export function isAuthenticated() {
  return !!getTokens()?.access
}

export async function fetchMe() {
  const { data } = await client.get('/users/me/')
  return data
}

export async function changePassword(payload) {
  const { data } = await client.post('/users/change_password/', payload)
  return data
}
