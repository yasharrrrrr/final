import { client } from './client'

export async function listProducts(params = {}) {
  const { data } = await client.get('/products/', { params })
  return data
}

export async function getProduct(id) {
  const { data } = await client.get(`/products/${id}/`)
  return data
}

export async function listFeatured() {
  const { data } = await client.get('/products/featured/')
  return data
}

export async function listBestsellers() {
  const { data } = await client.get('/products/bestsellers/')
  return data
}

export async function listOnSale() {
  const { data } = await client.get('/products/on_sale/')
  return data
}

export async function listCategories() {
  const { data } = await client.get('/categories/')
  return data
}

export async function getReviews(productId) {
  const { data } = await client.get(`/products/${productId}/reviews/`)
  return data
}

export async function postReview(productId, payload) {
  const { data } = await client.post(`/products/${productId}/reviews/`, payload)
  return data
}

export async function addToWishlist(productId) {
  const { data } = await client.post(`/products/${productId}/add_to_wishlist/`)
  return data
}

export async function removeFromWishlist(productId) {
  const { data } = await client.delete(`/products/${productId}/remove_from_wishlist/`)
  return data
}

export async function listWishlist() {
  const { data } = await client.get('/wishlist/')
  return data
}
