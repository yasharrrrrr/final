import axios from 'axios'

// In production this is same-origin behind the nginx gateway ("/api").
// In dev, Vite's proxy (vite.config.js) forwards "/api" to the Django backend.
const baseURL = import.meta.env.VITE_API_URL || '/api'

const client = axios.create({ baseURL })

function getTokens() {
  try {
    return JSON.parse(localStorage.getItem('baorco_tokens') || 'null')
  } catch {
    return null
  }
}

function setTokens(tokens) {
  if (tokens) localStorage.setItem('baorco_tokens', JSON.stringify(tokens))
  else localStorage.removeItem('baorco_tokens')
}

client.interceptors.request.use((config) => {
  const tokens = getTokens()
  if (tokens?.access) {
    config.headers.Authorization = `Bearer ${tokens.access}`
  }
  return config
})

let refreshPromise = null

client.interceptors.response.use(
  (response) => response,
  async (error) => {
    const { config, response } = error
    if (response?.status !== 401 || config._retried) {
      return Promise.reject(error)
    }

    const tokens = getTokens()
    if (!tokens?.refresh) {
      setTokens(null)
      return Promise.reject(error)
    }

    config._retried = true

    try {
      if (!refreshPromise) {
        refreshPromise = axios
          .post(`${baseURL}/auth/token/refresh/`, { refresh: tokens.refresh })
          .finally(() => {
            refreshPromise = null
          })
      }
      const { data } = await refreshPromise
      setTokens({ ...tokens, access: data.access })
      config.headers.Authorization = `Bearer ${data.access}`
      return client(config)
    } catch (refreshError) {
      setTokens(null)
      return Promise.reject(refreshError)
    }
  }
)

export { client, getTokens, setTokens }
