import { client } from './client'

export async function getCart() {
  const { data } = await client.get('/cart/list/')
  return data
}

export async function addItem(productId, quantity = 1) {
  const { data } = await client.post('/cart/add_item/', { product_id: productId, quantity })
  return data
}

export async function updateItem(cartItemId, quantity) {
  const { data } = await client.post('/cart/update_item/', { cart_item_id: cartItemId, quantity })
  return data
}

export async function removeItem(cartItemId) {
  const { data } = await client.post('/cart/remove_item/', { cart_item_id: cartItemId })
  return data
}

export async function clearCart() {
  const { data } = await client.post('/cart/clear/')
  return data
}
