/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        bg: '#FAF6F0',
        surface: '#FFFFFF',
        ink: '#2B2420',
        muted: '#8A7E72',
        primary: {
          DEFAULT: '#8B5E34',
          dark: '#6E4A28',
          light: '#A87A4E',
        },
        accent: {
          DEFAULT: '#C08A3E',
          light: '#E0B876',
        },
        line: '#E8DFD3',
        danger: '#B3463B',
      },
      fontFamily: {
        sans: ['Vazirmatn', 'system-ui', 'sans-serif'],
      },
      borderRadius: {
        xl2: '1.25rem',
      },
    },
  },
  plugins: [],
}
